<?php require_once('header.php'); ?>

<?php
// Check if the customer is logged in or not
if(!isset($_SESSION['customer_logged_in'])) {
    header('location: login.php');
    exit;
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['form1'])) {
    try {
        // Prepare update statement
        $statement = $pdo->prepare("
            UPDATE tbl_customer SET 
                cust_name = ?,
                cust_cname = ?,
                cust_email = ?,
                cust_phone = ?,
                cust_address = ?,
                cust_country = ?,
                cust_city = ?,
                cust_state = ?,
                cust_zip = ?
            WHERE cust_id = ?
        ");
        
        // Execute update with new values
        $statement->execute([
            $_POST['cust_name'],
            $_POST['cust_cname'],
            $_POST['cust_email'],
            $_POST['cust_phone'],
            $_POST['cust_address'],
            $_POST['cust_country'],
            $_POST['cust_city'],
            $_POST['cust_state'],
            $_POST['cust_zip'],
            $_SESSION['customer_id']
        ]);

        // Update session variables
        $_SESSION['customer_name'] = $_POST['cust_name'];
        $_SESSION['customer_email'] = $_POST['cust_email'];

        // Redirect to profile page with success message
        $_SESSION['success_message'] = "Profile updated successfully!";
        header('Location: profile.php');
        exit;
    } catch (PDOException $e) {
        // Handle database error
        $error_message = "An error occurred while updating your profile. Please try again later.";
    }
}

// Get current customer details
$statement = $pdo->prepare("SELECT * FROM tbl_customer WHERE cust_id = ?");
$statement->execute([$_SESSION['customer_id']]);
$user = $statement->fetch(PDO::FETCH_ASSOC);
?>

<div class="page">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="user-content">
                    <div class="profile-header text-center py-5 mb-5">
                        <h2 class="mb-3">Edit Profile</h2>
                        <p class="lead">Update your account information</p>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-body">
                                    <form action="" method="post">
                                        <?php $csrf->echoInputField(); ?>
                                        
                                        <div class="form-group">
                                            <label for="cust_name">Full Name *</label>
                                            <input type="text" class="form-control" id="cust_name" name="cust_name" value="<?php echo htmlspecialchars($user['cust_name']); ?>" required>
                                        </div>

                                        <div class="form-group">
                                            <label for="cust_cname">Company Name *</label>
                                            <input type="text" class="form-control" id="cust_cname" name="cust_cname" value="<?php echo htmlspecialchars($user['cust_cname']); ?>" required>
                                        </div>

                                        <div class="form-group">
                                            <label for="cust_email">Email *</label>
                                            <input type="email" class="form-control" id="cust_email" name="cust_email" value="<?php echo htmlspecialchars($user['cust_email']); ?>" required>
                                        </div>

                                        <div class="form-group">
                                            <label for="cust_phone">Phone *</label>
                                            <input type="text" class="form-control" id="cust_phone" name="cust_phone" value="<?php echo htmlspecialchars($user['cust_phone']); ?>" required>
                                        </div>

                                        <div class="form-group">
                                            <label for="cust_address">Address *</label>
                                            <textarea class="form-control" id="cust_address" name="cust_address" rows="3" required><?php echo htmlspecialchars($user['cust_address']); ?></textarea>
                                        </div>

                                        <div class="form-group">
                                            <label for="cust_country">Country *</label>
                                            <select class="form-control" id="cust_country" name="cust_country" required>
                                                <option value="">Select Country</option>
                                                <?php
                                                $statement = $pdo->prepare("SELECT * FROM tbl_country ORDER BY country_name");
                                                $statement->execute();
                                                $result = $statement->fetchAll(PDO::FETCH_ASSOC);
                                                foreach ($result as $row) {
                                                    $selected = ($row['country_id'] == $user['cust_country']) ? 'selected' : '';
                                                    echo '<option value="' . $row['country_id'] . '" ' . $selected . '>' . $row['country_name'] . '</option>';
                                                }
                                                ?>
                                            </select>
                                        </div>

                                        <div class="form-group">
                                            <label for="cust_city">City *</label>
                                            <input type="text" class="form-control" id="cust_city" name="cust_city" value="<?php echo htmlspecialchars($user['cust_city']); ?>" required>
                                        </div>

                                        <div class="form-group">
                                            <label for="cust_state">State *</label>
                                            <input type="text" class="form-control" id="cust_state" name="cust_state" value="<?php echo htmlspecialchars($user['cust_state']); ?>" required>
                                        </div>

                                        <div class="form-group">
                                            <label for="cust_zip">Zip Code *</label>
                                            <input type="text" class="form-control" id="cust_zip" name="cust_zip" value="<?php echo htmlspecialchars($user['cust_zip']); ?>" required>
                                        </div>

                                        <div class="form-group text-center mt-4">
                                            <button type="submit" name="form1" class="btn btn-primary">Update Profile</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .profile-header {
        background: #f8f9fa;
        border-radius: 10px;
        padding: 3rem 2rem;
    }
    
    .profile-header h2 {
        color: #2c3e50;
        font-weight: 600;
    }
    
    .profile-header .lead {
        color: #666;
        font-size: 1.1rem;
    }
    
    .card {
        border: none;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }
    
    .form-group {
        margin-bottom: 1.5rem;
    }
    
    .form-group label {
        font-weight: 500;
        color: #2c3e50;
        margin-bottom: 0.5rem;
    }
    
    .form-control {
        border-radius: 5px;
        padding: 0.8rem;
    }
    
    @media (max-width: 768px) {
        .profile-header {
            padding: 2rem 1rem;
        }
    }
</style>

<?php require_once('footer.php'); ?>
