<?php
require_once('header.php');
require_once('language.php');
require_once('header.php'); // Ensure DB connection is included

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['customer'])) {
    header('location: ' . BASE_URL . 'logout.php');
    exit;
}

$error_message = "";
$success_message = "";

if (isset($_POST['form2'])) {
    $email = trim($_POST['email']);
    $old_password = trim($_POST['old_password']);
    $new_password = trim($_POST['new_password']);
    $confirm_password = trim($_POST['confirm_password']);

    // Check if all fields are filled
    if (empty($email) || empty($old_password) || empty($new_password) || empty($confirm_password)) {
        $error_message = "All fields are required!";
    } else {
        // Fetch the stored password
        $statement = $pdo->prepare("SELECT cust_id, cust_password FROM tbl_customer WHERE cust_email=?");
        $statement->execute([$email]);
        $result = $statement->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            $cust_id = $result['cust_id'];
            $stored_password = $result['cust_password'];

            // Check if stored password is MD5
            if ($stored_password === md5($old_password)) {
                // If old password is in MD5, upgrade to bcrypt
                $new_password_hash = password_hash($new_password, PASSWORD_DEFAULT);
                $update_stmt = $pdo->prepare("UPDATE tbl_customer SET cust_password=? WHERE cust_id=?");
                $update_stmt->execute([$new_password_hash, $cust_id]);

                $success_message = "Password updated successfully!";
            } elseif (password_verify($old_password, $stored_password)) {
                // If stored password is already bcrypt
                if ($new_password !== $confirm_password) {
                    $error_message = "New password and confirm password do not match!";
                } else {
                    $new_password_hash = password_hash($new_password, PASSWORD_DEFAULT);
                    $update_stmt = $pdo->prepare("UPDATE tbl_customer SET cust_password=? WHERE cust_id=?");
                    $update_stmt->execute([$new_password_hash, $cust_id]);

                    $success_message = "Password changed successfully!";
                }
            } else {
                $error_message = "Old password is incorrect!";
            }
        } else {
            $error_message = "User not found!";
        }
    }
}
?>

<div class="page">
    <div class="container">
        <div class="row">            
            <div class="col-md-12"> 
                <?php require_once('customer-sidebar.php'); ?>
            </div>
            <div class="col-md-12">
                <div class="user-content">
                    <?php
                    if (!empty($error_message)) {
                        echo "<div class='alert alert-danger'>$error_message</div>";
                    }
                    if (!empty($success_message)) {
                        echo "<div class='alert alert-success'>$success_message</div>";
                    }
                    ?>

                    <h3>Change Password</h3>
                    <form action="" method="post">
                        <div class="form-group">
                            <label>Login Email</label>
                            <input type="email" class="form-control" name="email" required>
                        </div>
                        <div class="form-group">
                            <label>Old Password</label>
                            <input type="password" class="form-control" name="old_password" required>
                        </div>
                        <div class="form-group">
                            <label>New Password</label>
                            <input type="password" class="form-control" name="new_password" required>
                        </div>
                        <div class="form-group">
                            <label>Confirm New Password</label>
                            <input type="password" class="form-control" name="confirm_password" required>
                        </div>
                        <input type="submit" class="btn btn-danger" value="Change Password" name="form2">
                    </form>
                </div>                
            </div>
        </div>
    </div>
</div>

<?php require_once('footer.php'); ?>
