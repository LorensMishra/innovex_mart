<?php 
session_start();
require_once('language.php');

// Define the missing constant if not already defined
if(!defined('LANG_VALUE_154')) {
    define('LANG_VALUE_154', 'Add to Cart');
}

require_once('header.php'); 

// Get banner image
$statement = $pdo->prepare("SELECT * FROM tbl_settings WHERE id=1");
$statement->execute();
$result = $statement->fetchAll(PDO::FETCH_ASSOC);                            
foreach ($result as $row) {
    $banner_product_category = $row['banner_product_category'];
}

// Validate category type and ID
if(!isset($_REQUEST['id']) || !isset($_REQUEST['type'])) {
    header('location: index.php');
    exit;
} 

$valid_types = ['top-category', 'mid-category', 'end-category'];
if(!in_array($_REQUEST['type'], $valid_types)) {
    header('location: index.php');
    exit;
}

// Get all categories
$top = $mid = $end = [];
$top1 = $mid1 = $end1 = [];
$mid2 = $end2 = [];

// Top categories
$statement = $pdo->prepare("SELECT * FROM tbl_top_category");
$statement->execute();
$result = $statement->fetchAll(PDO::FETCH_ASSOC);                            
foreach ($result as $row) {
    $top[] = $row['tcat_id'];
    $top1[] = $row['tcat_name'];
}

// Mid categories
$statement = $pdo->prepare("SELECT * FROM tbl_mid_category");
$statement->execute();
$result = $statement->fetchAll(PDO::FETCH_ASSOC);                            
foreach ($result as $row) {
    $mid[] = $row['mcat_id'];
    $mid1[] = $row['mcat_name'];
    $mid2[] = $row['tcat_id'];
}

// End categories
$statement = $pdo->prepare("SELECT * FROM tbl_end_category");
$statement->execute();
$result = $statement->fetchAll(PDO::FETCH_ASSOC);                            
foreach ($result as $row) {
    $end[] = $row['ecat_id'];
    $end1[] = $row['ecat_name'];
    $end2[] = $row['mcat_id'];
}

// Process based on category type
$final_ecat_ids = [];
$title = '';

if($_REQUEST['type'] == 'top-category') {
    if(!in_array($_REQUEST['id'], $top)) {
        header('location: index.php');
        exit;
    }
    
    // Get title
    foreach ($top as $i => $id) {
        if($id == $_REQUEST['id']) {
            $title = $top1[$i];
            break;
        }
    }
    
    // Find all end category IDs under this top category
    $arr1 = $arr2 = [];
    foreach ($mid as $i => $id) {
        if($mid2[$i] == $_REQUEST['id']) {
            $arr1[] = $id;
        }
    }
    
    foreach ($arr1 as $mcat_id) {
        foreach ($end as $i => $id) {
            if($end2[$i] == $mcat_id) {
                $arr2[] = $id;
            }
        }   
    }
    $final_ecat_ids = $arr2;
}
elseif($_REQUEST['type'] == 'mid-category') {
    if(!in_array($_REQUEST['id'], $mid)) {
        header('location: index.php');
        exit;
    }
    
    // Get title
    foreach ($mid as $i => $id) {
        if($id == $_REQUEST['id']) {
            $title = $mid1[$i];
            break;
        }
    }
    
    // Find all end category IDs under this mid category
    $arr2 = [];        
    foreach ($end as $i => $id) {
        if($end2[$i] == $_REQUEST['id']) {
            $arr2[] = $id;
        }
    }
    $final_ecat_ids = $arr2;
}
elseif($_REQUEST['type'] == 'end-category') {
    if(!in_array($_REQUEST['id'], $end)) {
        header('location: index.php');
        exit;
    }
    
    // Get title
    foreach ($end as $i => $id) {
        if($id == $_REQUEST['id']) {
            $title = $end1[$i];
            break;
        }
    }
    $final_ecat_ids = [$_REQUEST['id']];
}
?>

<div class="page-banner" style="background-image: url(assets/uploads/<?php echo $banner_product_category; ?>)">
    <div class="inner">
        <h1><?php echo LANG_VALUE_50; ?> <?php echo $title; ?></h1>
    </div>
</div>

<div class="page">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <?php require_once('sidebar-category.php'); ?>
            </div>
            <div class="col-md-9">
                <h3><?php echo LANG_VALUE_51; ?> "<?php echo $title; ?>"</h3>
                <div class="product product-cat">
                    <div class="row">
                        <?php
                        // Check if any products exist in these categories
                        $prod_count = 0;
                        $prod_table_ecat_ids = [];
                        
                        $statement = $pdo->prepare("SELECT ecat_id FROM tbl_product");
                        $statement->execute();
                        $result = $statement->fetchAll(PDO::FETCH_COLUMN, 0);
                        $prod_table_ecat_ids = $result;

                        foreach($final_ecat_ids as $ecat_id) {
                            if(in_array($ecat_id, $prod_table_ecat_ids)) {
                                $prod_count++;
                            }
                        }

                        if($prod_count == 0) {
                            echo '<div class="pl_15">'.LANG_VALUE_153.'</div>';
                        } else {
                            foreach($final_ecat_ids as $ecat_id) {
                                $statement = $pdo->prepare("SELECT * FROM tbl_product WHERE ecat_id=? AND p_is_active=?");
                                $statement->execute(array($ecat_id, 1));
                                $products = $statement->fetchAll(PDO::FETCH_ASSOC);
                                
                                foreach ($products as $row) {
                                    // Calculate average rating
                                    $avg_rating = 0;
                                    $statement1 = $pdo->prepare("SELECT AVG(rating) as avg_rating FROM tbl_rating WHERE p_id=?");
                                    $statement1->execute(array($row['p_id']));
                                    $rating_data = $statement1->fetch(PDO::FETCH_ASSOC);
                                    $avg_rating = round($rating_data['avg_rating'] * 2) / 2; // Round to nearest 0.5
                                    ?>
                                    <div class="col-md-4 item item-product-cat">
                                        <div class="inner">
                                            <div class="thumb">
                                                <div class="photo" style="background-image:url(assets/uploads/<?php echo $row['p_featured_photo']; ?>);"></div>
                                                <div class="overlay"></div>
                                            </div>
                                            <div class="text">
                                                <h3><a href="product.php?id=<?php echo $row['p_id']; ?>"><?php echo $row['p_name']; ?></a></h3>
                                                <h4>
                                                    <?php echo LANG_VALUE_1; ?><?php echo $row['p_current_price']; ?> 
                                                    <?php if($row['p_old_price'] != ''): ?>
                                                    <del>
                                                        <?php echo LANG_VALUE_1; ?><?php echo $row['p_old_price']; ?>
                                                    </del>
                                                    <?php endif; ?>
                                                </h4>
                                                <div class="rating">
                                                    <?php
                                                    // Display star rating
                                                    $full_stars = floor($avg_rating);
                                                    $half_star = ($avg_rating - $full_stars) > 0;
                                                    $empty_stars = 5 - $full_stars - ($half_star ? 1 : 0);
                                                    
                                                    for ($i=0; $i<$full_stars; $i++) {
                                                        echo '<i class="fa fa-star"></i>';
                                                    }
                                                    if ($half_star) {
                                                        echo '<i class="fa fa-star-half-o"></i>';
                                                    }
                                                    for ($i=0; $i<$empty_stars; $i++) {
                                                        echo '<i class="fa fa-star-o"></i>';
                                                    }
                                                    ?>
                                                </div>
                                                <?php if($row['p_qty'] == 0): ?>
                                                    <div class="out-of-stock">
                                                        <div class="inner">
                                                            Out Of Stock
                                                        </div>
                                                    </div>
                                                <?php else: ?>
                                                    <p><a href="add_to_cart.php?id=<?php echo $row['p_id']; ?>" class="btn btn-primary"><?php echo LANG_VALUE_154; ?></a></p>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                }
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once('footer.php'); ?>