<?php
// Language definitions for eCommerce System

// General UI Elements
if (!defined('LANG_VALUE_1')) {
    define('LANG_VALUE_1', '₹');
}
if (!defined('LANG_VALUE_5')) {
    define('LANG_VALUE_5', 'Update');
}
if (!defined('LANG_VALUE_8')) {
    define('LANG_VALUE_8', 'Product');
}
if (!defined('LANG_VALUE_14')) {
    define('LANG_VALUE_14', 'Logout');
}

// Shopping Cart Related
if (!defined('LANG_VALUE_18')) {
    define('LANG_VALUE_18', 'Shopping Cart');
}
if (!defined('LANG_VALUE_20')) {
    define('LANG_VALUE_20', 'Update Cart');
}
if (!defined('LANG_VALUE_21')) {
    define('LANG_VALUE_21', 'Continue Shopping');
}
if (!defined('LANG_VALUE_23')) {
    define('LANG_VALUE_23', 'Proceed to Checkout');
}
if (!defined('LANG_VALUE_47')) {
    define('LANG_VALUE_47', 'Size');
}
if (!defined('LANG_VALUE_55')) {
    define('LANG_VALUE_55', 'Total');
}
if (!defined('LANG_VALUE_82')) {
    define('LANG_VALUE_82', 'Subtotal');
}
if (!defined('LANG_VALUE_83')) {
    define('LANG_VALUE_83', 'Action');
}
if (!defined('LANG_VALUE_85')) {
    define('LANG_VALUE_85', 'Continue Shopping');
}
if (!defined('LANG_VALUE_154')) {
    define('LANG_VALUE_154', 'Add to Cart');
}

// User Account Sections
if (!defined('LANG_VALUE_24')) {
    define('LANG_VALUE_24', 'Orders');
}
if (!defined('LANG_VALUE_89')) {
    define('LANG_VALUE_89', 'Dashboard');
}
if (!defined('LANG_VALUE_99')) {
    define('LANG_VALUE_99', 'Change Password');
}
if (!defined('LANG_VALUE_117')) {
    define('LANG_VALUE_117', 'Profile Update');
}

// Address Information
if (!defined('LANG_VALUE_86')) {
    define('LANG_VALUE_86', 'Billing Information');
}
if (!defined('LANG_VALUE_87')) {
    define('LANG_VALUE_87', 'Shipping Information');
}
if (!defined('LANG_VALUE_88')) {
    define('LANG_VALUE_88', 'Billing & Shipping');
}
if (!defined('LANG_VALUE_102')) {
    define('LANG_VALUE_102', 'Name');
}
if (!defined('LANG_VALUE_103')) {
    define('LANG_VALUE_103', 'Company Name');
}
if (!defined('LANG_VALUE_104')) {
    define('LANG_VALUE_104', 'Phone');
}
if (!defined('LANG_VALUE_105')) {
    define('LANG_VALUE_105', 'Address');
}
if (!defined('LANG_VALUE_106')) {
    define('LANG_VALUE_106', 'Country');
}
if (!defined('LANG_VALUE_107')) {
    define('LANG_VALUE_107', 'City');
}
if (!defined('LANG_VALUE_108')) {
    define('LANG_VALUE_108', 'State');
}
if (!defined('LANG_VALUE_109')) {
    define('LANG_VALUE_109', 'Zip Code');
}

// Validation Messages
if (!defined('LANG_VALUE_122')) {
    define('LANG_VALUE_122', 'Billing and shipping information updated successfully.');
}
if (!defined('LANG_VALUE_123')) {
    define('LANG_VALUE_123', 'Name field cannot be empty.');
}
if (!defined('LANG_VALUE_124')) {
    define('LANG_VALUE_124', 'Phone field cannot be empty.');
}
if (!defined('LANG_VALUE_125')) {
    define('LANG_VALUE_125', 'Address field cannot be empty.');
}
if (!defined('LANG_VALUE_126')) {
    define('LANG_VALUE_126', 'Country field cannot be empty.');
}
if (!defined('LANG_VALUE_127')) {
    define('LANG_VALUE_127', 'City field cannot be empty.');
}
if (!defined('LANG_VALUE_128')) {
    define('LANG_VALUE_128', 'State field cannot be empty.');
}
if (!defined('LANG_VALUE_129')) {
    define('LANG_VALUE_129', 'Zip Code field cannot be empty.');
}
if (!defined('LANG_VALUE_130')) {
    define('LANG_VALUE_130', 'Your information has been successfully updated.');
}

// Authentication Messages
if (!defined('LANG_VALUE_133')) {
    define('LANG_VALUE_133', 'Customer not found.');
}
if (!defined('LANG_VALUE_139')) {
    define('LANG_VALUE_139', 'Incorrect password.');
}
if (!defined('LANG_VALUE_140')) {
    define('LANG_VALUE_140', 'User account is inactive.');
}
if (!defined('LANG_VALUE_141')) {
    define('LANG_VALUE_141', 'Your password has been successfully updated.');
}
if (!defined('LANG_VALUE_147')) {
    define('LANG_VALUE_147', 'This email is already registered.');
}

// Product Related
if (!defined('LANG_VALUE_153')) {
    define('LANG_VALUE_153', 'No products found.');
}
if (!defined('LANG_VALUE_157')) {
    define('LANG_VALUE_157', 'Color'); // Define the constant for color
}
if (!defined('LANG_VALUE_158')) {
    define('LANG_VALUE_158', 'Unit Price');
}
if (!defined('LANG_VALUE_159')) {
    define('LANG_VALUE_159', 'Your defined text here');
}
if (!defined('LANG_VALUE_161')) {
    define('LANG_VALUE_161', 'Proceed to Payment');
}
if (!defined('LANG_VALUE_162')) {
    define('LANG_VALUE_162', 'Shipping Information');
}

// Checkout Page
if (!defined('LANG_VALUE_33')) {
    define('LANG_VALUE_33', 'Payment Method');
}
if (!defined('LANG_VALUE_34')) {
    define('LANG_VALUE_34', 'Select Payment Method');
}
if (!defined('LANG_VALUE_35')) {
    define('LANG_VALUE_35', 'Please select a payment method');
}
if (!defined('LANG_VALUE_36')) {
    define('LANG_VALUE_36', 'PayPal');
}
if (!defined('LANG_VALUE_38')) {
    define('LANG_VALUE_38', 'Bank Transfer');
}
if (!defined('LANG_VALUE_43')) {
    define('LANG_VALUE_43', 'Bank Details');
}
if (!defined('LANG_VALUE_44')) {
    define('LANG_VALUE_44', 'Transaction Details');
}
if (!defined('LANG_VALUE_45')) {
    define('LANG_VALUE_45', 'Please provide your transaction details after making the payment');
}
if (!defined('LANG_VALUE_46')) {
    define('LANG_VALUE_46', 'Proceed to Payment');
}
?>