<?php
session_start();
require_once('config.php'); // Include database connection settings

// Check if product ID is set
if (isset($_GET['id'])) {
    $product_id = intval($_GET['id']);

    // Assuming you have a function to get product details
    $statement = $pdo->prepare("SELECT * FROM tbl_product WHERE p_id = ?");
    $statement->execute([$product_id]);
    $product = $statement->fetch(PDO::FETCH_ASSOC);

    if ($product) {
        // Initialize wishlist if it doesn't exist
        if (!isset($_SESSION['wishlist'])) {
            $_SESSION['wishlist'] = [];
        }

        // Add product to wishlist
        $_SESSION['wishlist'][$product['p_id']] = [
            'name' => $product['p_name'],
            'price' => $product['p_current_price'],
            'featured_photo' => $product['p_featured_photo']
        ];

        // Redirect to the wishlist page or show success message
        header('Location: wishlist.php');
        exit;
    } else {
        // Product not found
        header('Location: index.php');
        exit;
    }
} else {
    // Redirect to home if no product ID is set
    header('Location: index.php');
    exit;
}
?>
