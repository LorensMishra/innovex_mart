<?php 
require_once('header.php');
require_once('language.php');

// Fetch banner from database
$statement = $pdo->prepare("SELECT banner_registration FROM tbl_settings WHERE id=1");
$statement->execute();
$result = $statement->fetch(PDO::FETCH_ASSOC);
$banner_registration = $result['banner_registration'] ?? 'default-banner.jpg';

// Handle form submission
if (isset($_POST['form1'])) {
    $valid = true;
    $error_message = '';

    // Validate Full Name (only characters, no numbers)
    if(empty($_POST['cust_name'])) {
        $valid = false;
        $error_message .= "Please enter your name.<br>";
    } elseif (!preg_match("/^[a-zA-Z\s]+$/", $_POST['cust_name'])) {
        $valid = false;
        $error_message .= "Full Name should contain only characters.<br>";
    }

    // Validate Company Name (only characters)
    if(!empty($_POST['cust_cname']) && !preg_match("/^[a-zA-Z\s]+$/", $_POST['cust_cname'])) {
        $valid = false;
        $error_message .= "Company Name should contain only characters.<br>";
    }

    // Validate Email
    if(empty($_POST['cust_email'])) {
        $valid = false;
        $error_message .= "Please enter your email address.<br>";
    } elseif (!filter_var($_POST['cust_email'], FILTER_VALIDATE_EMAIL)) {
        $valid = false;
        $error_message .= "Please enter a valid email address.<br>";
    }

    // Validate Phone Number (only numbers)
    if(empty($_POST['cust_phone'])) {
        $valid = false;
        $error_message .= "Please enter your phone number.<br>";
    } elseif (!preg_match("/^[0-9]+$/", $_POST['cust_phone'])) {
        $valid = false;
        $error_message .= "Phone number should contain only numbers.<br>";
    }

    // Validate Address (characters and numbers allowed)
    if(empty($_POST['cust_address'])) {
        $valid = false;
        $error_message .= "Please enter your address.<br>";
    }

    // Validate Country (only characters)
    if(empty($_POST['cust_country'])) {
        $valid = false;
        $error_message .= "Please select your country.<br>";
    }

    // Validate City (only characters)
    if(empty($_POST['cust_city'])) {
        $valid = false;
        $error_message .= "Please enter your city.<br>";
    } elseif (!preg_match("/^[a-zA-Z\s]+$/", $_POST['cust_city'])) {
        $valid = false;
        $error_message .= "City should contain only characters.<br>";
    }

    // Validate State (only characters)
    if(empty($_POST['cust_state'])) {
        $valid = false;
        $error_message .= "Please enter your state.<br>";
    } elseif (!preg_match("/^[a-zA-Z\s]+$/", $_POST['cust_state'])) {
        $valid = false;
        $error_message .= "State should contain only characters.<br>";
    }

    // Validate Zip Code (only numbers)
    if(empty($_POST['cust_zip'])) {
        $valid = false;
        $error_message .= "Please enter your zip code.<br>";
    } elseif (!preg_match("/^[0-9]+$/", $_POST['cust_zip'])) {
        $valid = false;
        $error_message .= "Zip Code should contain only numbers.<br>";
    }

    // Validate Password
    if(empty($_POST['cust_password'])) {
        $valid = false;
        $error_message .= "Please enter a password.<br>";
    } elseif (strlen($_POST['cust_password']) < 8) {
        $valid = false;
        $error_message .= "Password must be at least 8 characters.<br>";
    } elseif (!preg_match("/^(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[^a-zA-Z0-9]).+$/", $_POST['cust_password'])) {
        $valid = false;
        $error_message .= "Password must contain characters, numbers, and special symbols.<br>";
    }

    // Validate Confirm Password
    if(empty($_POST['cust_re_password'])) {
        $valid = false;
        $error_message .= "Please re-enter your password.<br>";
    } elseif ($_POST['cust_password'] !== $_POST['cust_re_password']) {
        $valid = false;
        $error_message .= "Passwords do not match.<br>";
    }

    if($valid) {
        try {
            // Check if email already exists
            $statement = $pdo->prepare("SELECT * FROM tbl_customer WHERE cust_email = ?");
            $statement->execute([$_POST['cust_email']]);
            if($statement->rowCount() > 0) {
                $error_message = "This email is already registered.<br>";
                $valid = false;
            }
        } catch(PDOException $e) {
            $error_message = "Database error: " . $e->getMessage();
            $valid = false;
        }
    }

    if($valid) {
        try {
            // Hash the password before storing
            $hashed_password = password_hash($_POST['cust_password'], PASSWORD_DEFAULT);
            
            // Insert new customer
            $statement = $pdo->prepare("INSERT INTO tbl_customer (
                cust_name, cust_cname, cust_email, cust_phone, cust_country, cust_address, 
                cust_city, cust_state, cust_zip, cust_password, cust_status, cust_datetime
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
            
            $statement->execute([
                $_POST['cust_name'],
                $_POST['cust_cname'],
                $_POST['cust_email'],
                $_POST['cust_phone'],
                (int)$_POST['cust_country'],
                $_POST['cust_address'],
                $_POST['cust_city'],
                $_POST['cust_state'],
                $_POST['cust_zip'],
                $hashed_password,
                1
            ]);
            
            $success_message = "Registration successful. Please login.";
            
        } catch(PDOException $e) {
            $error_message = "Database error: " . $e->getMessage();
        }
    }
}
?>

<div class="page-banner" style="background-color:#444;background-image: url(assets/uploads/<?= htmlspecialchars($banner_registration) ?>);">
    <div class="inner">
        <h1><?= LANG_VALUE_16 ?></h1>
    </div>
</div>

<div class="page">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="user-content">
                    <h3><?php echo LANG_VALUE_11; ?></h3>
                    
                    <?php if(!empty($error_message)): ?>
                        <div class="alert alert-danger"><?php echo $error_message; ?></div>
                    <?php endif; ?>
                    
                    <?php if(!empty($success_message)): ?>
                        <div class="alert alert-success"><?php echo $success_message; ?></div>
                    <?php endif; ?>
                    
                    <form action="" method="post" class="needs-validation" novalidate>
                        <?php $csrf->echoInputField(); ?>
                        <div class="row">
                            <div class="col-md-6 form-group">
                                <label><?php echo LANG_VALUE_102; ?> *</label>
                                <input type="text" class="form-control" name="cust_name" 
                                    value="<?php echo htmlspecialchars($_POST['cust_name'] ?? ''); ?>" required>
                                <div class="invalid-feedback">
                                    Please enter your name.
                                </div>
                            </div>
                            <div class="col-md-6 form-group">
                                <label><?php echo LANG_VALUE_103; ?></label>
                                <input type="text" class="form-control" name="cust_cname" 
                                    value="<?php echo htmlspecialchars($_POST['cust_cname'] ?? ''); ?>">
                                <div class="invalid-feedback">
                                    Company Name should contain only characters.
                                </div>
                            </div>
                            <div class="col-md-6 form-group">
                                <label><?php echo LANG_VALUE_94; ?> *</label>
                                <input type="email" class="form-control" name="cust_email" 
                                    value="<?php echo htmlspecialchars($_POST['cust_email'] ?? ''); ?>" required>
                                <div class="invalid-feedback">
                                    Please enter a valid email address.
                                </div>
                            </div>
                            <div class="col-md-6 form-group">
                                <label><?php echo LANG_VALUE_104; ?> *</label>
                                <input type="tel" class="form-control" name="cust_phone" 
                                    value="<?php echo htmlspecialchars($_POST['cust_phone'] ?? ''); ?>" required>
                                <div class="invalid-feedback">
                                    Phone number should contain only numbers.
                                </div>
                            </div>
                            <div class="col-md-12 form-group">
                                <label><?php echo LANG_VALUE_105; ?> *</label>
                                <textarea name="cust_address" class="form-control" required><?php 
                                    echo htmlspecialchars($_POST['cust_address'] ?? ''); 
                                ?></textarea>
                                <div class="invalid-feedback">
                                    Please enter your address.
                                </div>
                            </div>
                            <div class="col-md-6 form-group">
                                <label><?php echo LANG_VALUE_106; ?> *</label>
                                <select name="cust_country" class="form-control" required>
                                    <option value="">Select country</option>
                                    <?php
                                    $statement = $pdo->prepare("SELECT * FROM tbl_country ORDER BY country_name ASC");
                                    $statement->execute();
                                    $countries = $statement->fetchAll(PDO::FETCH_ASSOC);
                                    
                                    foreach ($countries as $country) {
                                        $selected = (isset($_POST['cust_country']) && $_POST['cust_country'] == $country['country_id']) ? 'selected' : '';
                                        echo '<option value="'.(int)$country['country_id'].'" '.$selected.'>'
                                            .htmlspecialchars($country['country_name']).'</option>';
                                    }
                                    ?>
                                </select>
                                <div class="invalid-feedback">
                                    Please select your country.
                                </div>
                            </div>
                            <div class="col-md-6 form-group">
                                <label><?php echo LANG_VALUE_107; ?> *</label>
                                <input type="text" class="form-control" name="cust_city" 
                                    value="<?php echo htmlspecialchars($_POST['cust_city'] ?? ''); ?>" required>
                                <div class="invalid-feedback">
                                    City should contain only characters.
                                </div>
                            </div>
                            <div class="col-md-6 form-group">
                                <label><?php echo LANG_VALUE_108; ?> *</label>
                                <input type="text" class="form-control" name="cust_state" 
                                    value="<?php echo htmlspecialchars($_POST['cust_state'] ?? ''); ?>" required>
                                <div class="invalid-feedback">
                                    State should contain only characters.
                                </div>
                            </div>
                            <div class="col-md-6 form-group">
                                <label><?php echo LANG_VALUE_109; ?> *</label>
                                <input type="text" class="form-control" name="cust_zip" 
                                    value="<?php echo htmlspecialchars($_POST['cust_zip'] ?? ''); ?>" required>
                                <div class="invalid-feedback">
                                    Zip Code should contain only numbers.
                                </div>
                            </div>
                            <div class="col-md-6 form-group">
                                <label><?php echo LANG_VALUE_96; ?> *</label>
                                <input type="password" class="form-control" name="cust_password" required>
                                <div class="invalid-feedback">
                                    Password must be at least 8 characters and contain characters, numbers, and special symbols.
                                </div>
                            </div>
                            <div class="col-md-6 form-group">
                                <label><?php echo LANG_VALUE_98; ?> *</label>
                                <input type="password" class="form-control" name="cust_re_password" required>
                                <div class="invalid-feedback">
                                    Please re-enter your password.
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary" name="form1"><?php echo LANG_VALUE_11; ?></button>
                        <div class="mt-3">
                            <p class="mb-0">Already have an account? 
                                <a href="login.php" class="text-decoration-none">Sign in</a>
                            </p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.form-control:invalid {
    border-color: #dc3545;
    background-color: #fff3f5;
}

.form-control:valid {
    border-color: #28a745;
    background-color: #f0f9f5;
}

.invalid-feedback {
    display: block;
    color: #dc3545;
    font-size: 0.875rem;
    margin-top: 0.25rem;
}
</style>

<script>
// Client-side validation
(() => {
    'use strict'
    const forms = document.querySelectorAll('.needs-validation')
    
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault()
                event.stopPropagation()
            }
            
            form.classList.add('was-validated')
        }, false)
    })

    // Add custom validation for specific fields
    const nameInput = document.querySelector('input[name="cust_name"]');
    const phoneInput = document.querySelector('input[name="cust_phone"]');
    const zipInput = document.querySelector('input[name="cust_zip"]');
    const cityInput = document.querySelector('input[name="cust_city"]');
    const stateInput = document.querySelector('input[name="cust_state"]');

    if (nameInput) {
        nameInput.addEventListener('input', () => {
            if (!nameInput.value.match(/^[a-zA-Z\s]+$/)) {
                nameInput.setCustomValidity('Full Name should contain only characters.');
            } else {
                nameInput.setCustomValidity('');
            }
        });
    }

    if (phoneInput) {
        phoneInput.addEventListener('input', () => {
            if (!phoneInput.value.match(/^[0-9]+$/)) {
                phoneInput.setCustomValidity('Phone number should contain only numbers.');
            } else {
                phoneInput.setCustomValidity('');
            }
        });
    }

    if (zipInput) {
        zipInput.addEventListener('input', () => {
            if (!zipInput.value.match(/^[0-9]+$/)) {
                zipInput.setCustomValidity('Zip Code should contain only numbers.');
            } else {
                zipInput.setCustomValidity('');
            }
        });
    }

    if (cityInput) {
        cityInput.addEventListener('input', () => {
            if (!cityInput.value.match(/^[a-zA-Z\s]+$/)) {
                cityInput.setCustomValidity('City should contain only characters.');
            } else {
                cityInput.setCustomValidity('');
            }
        });
    }

    if (stateInput) {
        stateInput.addEventListener('input', () => {
            if (!stateInput.value.match(/^[a-zA-Z\s]+$/)) {
                stateInput.setCustomValidity('State should contain only characters.');
            } else {
                stateInput.setCustomValidity('');
            }
        });
    }
})()
</script>

<?php require_once('footer.php'); ?>