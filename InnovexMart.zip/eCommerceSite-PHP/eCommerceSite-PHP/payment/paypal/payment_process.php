<?php
ob_start();
session_start();
require_once('../../admin/inc/config.php');

$error_message = '';

// Initialize all cart arrays with proper fallbacks
$arr_cart_size_name = $_SESSION['cart_size_name'] ?? [];
$arr_cart_color_name = $_SESSION['cart_color_name'] ?? [];
$arr_cart_p_id = $_SESSION['cart_p_id'] ?? [];
$arr_cart_p_name = $_SESSION['cart_p_name'] ?? [];
$arr_cart_p_qty = $_SESSION['cart_p_qty'] ?? [];
$arr_cart_p_current_price = $_SESSION['cart_p_current_price'] ?? [];

// Verify we have products to process
if(empty($arr_cart_p_id)) {
    die("Error: No products in cart");
}

$statement = $pdo->prepare("SELECT * FROM tbl_settings WHERE id=1");
$statement->execute();
$result = $statement->fetchAll(PDO::FETCH_ASSOC);
foreach ($result as $row) {
    $paypal_email = $row['paypal_email'];
}

$return_url = 'payment_success.php';
$cancel_url = 'payment.php';
$notify_url = 'payment/paypal/verify_process.php';

$item_name = 'Product Item(s)';
$item_amount = $_POST['final_total'];
$item_number = time();

$payment_date = date('Y-m-d H:i:s');

// Check if paypal request or response
if (!isset($_POST["txn_id"]) && !isset($_POST["txn_type"])) {
    $querystring = '';
    
    // Firstly Append paypal account to querystring
    $querystring .= "?business=".urlencode($paypal_email)."&";
    
    // Append item details to querystring
    $querystring .= "item_name=".urlencode($item_name)."&";
    $querystring .= "amount=".urlencode($item_amount)."&";
    $querystring .= "item_number=".urlencode($item_number)."&";
    
    //loop for posted values and append to querystring
    foreach($_POST as $key => $value) {
        $value = urlencode(stripslashes($value));
        $querystring .= "$key=$value&";
    }
    
    // Append paypal return addresses
    $querystring .= "return=".urlencode(stripslashes($return_url))."&";
    $querystring .= "cancel_return=".urlencode(stripslashes($cancel_url))."&";
    $querystring .= "notify_url=".urlencode($notify_url);

    try {
        // Insert payment record
        $statement = $pdo->prepare("INSERT INTO tbl_payment (
            customer_id,
            customer_name,
            customer_email,
            payment_date,
            txnid, 
            paid_amount,
            card_number,
            card_cvv,
            card_month,
            card_year,
            bank_transaction_info,
            payment_method,
            payment_status,
            shipping_status,
            payment_id
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        
        $statement->execute([
            $_SESSION['customer']['cust_id'],
            $_SESSION['customer']['cust_name'],
            $_SESSION['customer']['cust_email'],
            $payment_date,
            '',
            $item_amount,
            '',
            '',
            '',
            '',
            '',
            'PayPal',
            'Pending',
            'Pending',
            $item_number
        ]);

        // Get current product quantities for stock update
        $statement = $pdo->prepare("SELECT p_id, p_qty FROM tbl_product");
        $statement->execute();
        $products = $statement->fetchAll(PDO::FETCH_ASSOC);
        
        $product_stock = [];
        foreach ($products as $product) {
            $product_stock[$product['p_id']] = $product['p_qty'];
        }

        // Process each cart item
        foreach($arr_cart_p_id as $i => $product_id) {
            // Insert order item
            $statement = $pdo->prepare("INSERT INTO tbl_order (
                product_id,
                product_name,
                size, 
                color,
                quantity, 
                unit_price, 
                payment_id
            ) VALUES (?, ?, ?, ?, ?, ?, ?)");
            
            $statement->execute([
                $product_id,
                $arr_cart_p_name[$i] ?? 'Unknown',
                $arr_cart_size_name[$i] ?? '',
                $arr_cart_color_name[$i] ?? '',
                $arr_cart_p_qty[$i] ?? 1,
                $arr_cart_p_current_price[$i] ?? 0,
                $item_number
            ]);

            // Update product stock
            if(isset($product_stock[$product_id])) {
                $new_qty = $product_stock[$product_id] - ($arr_cart_p_qty[$i] ?? 0);
                $statement = $pdo->prepare("UPDATE tbl_product SET p_qty=? WHERE p_id=?");
                $statement->execute([$new_qty, $product_id]);
            }
        }

        // Clear the cart
        unset($_SESSION['cart_p_id']);
        unset($_SESSION['cart_size_id']);
        unset($_SESSION['cart_size_name']);
        unset($_SESSION['cart_color_id']);
        unset($_SESSION['cart_color_name']);
        unset($_SESSION['cart_p_qty']);
        unset($_SESSION['cart_p_current_price']);
        unset($_SESSION['cart_p_name']);
        unset($_SESSION['cart_p_featured_photo']);

        // Redirect to PayPal
        header('Location: https://www.paypal.com/cgi-bin/webscr'.$querystring);
        exit();
        
    } catch(PDOException $e) {
        error_log("Payment processing error: " . $e->getMessage());
        die("An error occurred during payment processing. Please try again.");
    }
} else {
    // Response from PayPal

    // read the post from PayPal system and add 'cmd'
    $req = 'cmd=_notify-validate';
    foreach ($_POST as $key => $value) {
        $value = urlencode(stripslashes($value));
        $value = preg_replace('/(.*[^%^0^D])(%0A)(.*)/i','${1}%0D%0A${3}',$value);// IPN fix
        $req .= "&$key=$value";
    }
    
    // assign posted variables to local variables
    $data['item_name']          = $_POST['item_name'];
    $data['item_number']        = $_POST['item_number'];
    $data['payment_status']     = $_POST['payment_status'];
    $data['payment_amount']     = $_POST['mc_gross'];
    $data['payment_currency']   = $_POST['mc_currency'];
    $data['txn_id']             = $_POST['txn_id'];
    $data['receiver_email']     = $_POST['receiver_email'];
    $data['payer_email']        = $_POST['payer_email'];
    $data['custom']             = $_POST['custom'];
        
    // post back to PayPal system to validate
    $header = "POST /cgi-bin/webscr HTTP/1.0\r\n";
    $header .= "Content-Type: application/x-www-form-urlencoded\r\n";
    $header .= "Content-Length: " . strlen($req) . "\r\n\r\n";
    
    $fp = fsockopen ('ssl://www.paypal.com', 443, $errno, $errstr, 30);
    
    if (!$fp) {
        // HTTP ERROR
        error_log("PayPal connection failed: $errstr ($errno)");
    } else {
        fputs($fp, $header . $req);
        while (!feof($fp)) {
            $res = fgets ($fp, 1024);
            if (strcmp($res, "VERIFIED") == 0) {
                // Payment verified - update your database accordingly
                try {
                    $statement = $pdo->prepare("UPDATE tbl_payment SET 
                        payment_status = 'Completed',
                        txnid = ?
                        WHERE payment_id = ?");
                    $statement->execute([$data['txn_id'], $data['item_number']]);
                } catch(PDOException $e) {
                    error_log("Payment verification update failed: " . $e->getMessage());
                }
            } else if (strcmp ($res, "INVALID") == 0) {
                // Payment invalid - log for investigation
                error_log("Invalid PayPal payment: " . print_r($data, true));
            }
        }
        fclose ($fp);
    }
}