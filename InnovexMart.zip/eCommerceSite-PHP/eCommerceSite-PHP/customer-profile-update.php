<?php 
require_once('header.php');
require_once('language.php');

// Check if customer is logged in
if (!isset($_SESSION['customer_id'])) {
    header('location: '.BASE_URL.'login.php');
    exit;
}

// Check if customer is inactive
$statement = $pdo->prepare("SELECT * FROM tbl_customer WHERE cust_id = ? AND cust_status = ?");
$statement->execute([$_SESSION['customer_id'], 0]);
if($statement->rowCount() > 0) {
    header('location: '.BASE_URL.'logout.php');
    exit;
}

// Get customer data
$statement = $pdo->prepare("SELECT * FROM tbl_customer WHERE cust_id = ?");
$statement->execute([$_SESSION['customer_id']]);
$customer = $statement->fetch(PDO::FETCH_ASSOC);

// Function to check if a field has an error
function hasError($field_name) {
    global $error_message;
    return strpos($error_message, $field_name) !== false;
}

// Handle form submission
if (isset($_POST['form1'])) {
    $valid = true;
    $error_message = '';

    // Validate Full Name (only characters, no numbers)
    if(empty($_POST['cust_name'])) {
        $valid = false;
        $error_message .= LANG_VALUE_123 . "<br>";
    } elseif (!preg_match("/^[a-zA-Z\s]+$/", $_POST['cust_name'])) {
        $valid = false;
        $error_message .= "Full Name should contain only characters.<br>";
    }

    // Validate Company Name (only characters)
    if(!empty($_POST['cust_cname']) && !preg_match("/^[a-zA-Z\s]+$/", $_POST['cust_cname'])) {
        $valid = false;
        $error_message .= "Company Name should contain only characters.<br>";
    }

    // Validate Email
    if(empty($_POST['cust_email'])) {
        $valid = false;
        $error_message .= "Please enter your email address.<br>";
    } elseif (!filter_var($_POST['cust_email'], FILTER_VALIDATE_EMAIL)) {
        $valid = false;
        $error_message .= "Please enter a valid email address.<br>";
    }

    // Validate Phone Number (only numbers)
    if(empty($_POST['cust_phone'])) {
        $valid = false;
        $error_message .= LANG_VALUE_124 . "<br>";
    } elseif (!preg_match("/^[0-9]+$/", $_POST['cust_phone'])) {
        $valid = false;
        $error_message .= "Phone number should contain only numbers.<br>";
    }

    // Validate Address (characters and numbers allowed)
    if(empty($_POST['cust_address'])) {
        $valid = false;
        $error_message .= LANG_VALUE_125 . "<br>";
    }

    // Validate Country (only characters)
    if(empty($_POST['cust_country'])) {
        $valid = false;
        $error_message .= LANG_VALUE_126 . "<br>";
    } elseif (!preg_match("/^[a-zA-Z\s]+$/", $_POST['cust_country'])) {
        $valid = false;
        $error_message .= "Please select your country.<br>";
    }

    // Validate City (only characters)
    if(empty($_POST['cust_city'])) {
        $valid = false;
        $error_message .= LANG_VALUE_127 . "<br>";
    } elseif (!preg_match("/^[a-zA-Z\s]+$/", $_POST['cust_city'])) {
        $valid = false;
        $error_message .= "City should contain only characters.<br>";
    }

    // Validate State (only characters)
    if(empty($_POST['cust_state'])) {
        $valid = false;
        $error_message .= LANG_VALUE_128 . "<br>";
    } elseif (!preg_match("/^[a-zA-Z\s]+$/", $_POST['cust_state'])) {
        $valid = false;
        $error_message .= "State should contain only characters.<br>";
    }

    // Validate Zip Code (only numbers)
    if(empty($_POST['cust_zip'])) {
        $valid = false;
        $error_message .= LANG_VALUE_129 . "<br>";
    } elseif (!preg_match("/^[0-9]+$/", $_POST['cust_zip'])) {
        $valid = false;
        $error_message .= "Zip Code should contain only numbers.<br>";
    }

    // Validate Password (characters, numbers, special symbols, minimum 8 chars)
    if(!empty($_POST['cust_password'])) {
        if(strlen($_POST['cust_password']) < 8) {
            $valid = false;
            $error_message .= "Password must be at least 8 characters.<br>";
        } elseif (!preg_match("/^(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[^a-zA-Z0-9]).+$/", $_POST['cust_password'])) {
            $valid = false;
            $error_message .= "Password must contain characters, numbers, and special symbols.<br>";
        }
    }

    // Validate Confirm Password
    if(!empty($_POST['cust_password']) && !empty($_POST['cust_confirm_password'])) {
        if($_POST['cust_password'] !== $_POST['cust_confirm_password']) {
            $valid = false;
            $error_message .= "Passwords do not match.<br>";
        }
    }

    if($valid) {
        try {
            // Update customer data
            $statement = $pdo->prepare("UPDATE tbl_customer SET 
                cust_name = ?, 
                cust_cname = ?, 
                cust_phone = ?, 
                cust_country = ?, 
                cust_address = ?, 
                cust_city = ?, 
                cust_state = ?, 
                cust_zip = ? 
                WHERE cust_id = ?");
            
            $statement->execute([
                htmlspecialchars($_POST['cust_name']),
                htmlspecialchars($_POST['cust_cname']),
                htmlspecialchars($_POST['cust_phone']),
                (int)$_POST['cust_country'],
                htmlspecialchars($_POST['cust_address']),
                htmlspecialchars($_POST['cust_city']),
                htmlspecialchars($_POST['cust_state']),
                htmlspecialchars($_POST['cust_zip']),
                $_SESSION['customer_id']
            ]);  
            
            $success_message = LANG_VALUE_130;

            // Update session data
            $_SESSION['customer_name'] = htmlspecialchars($_POST['cust_name']);
            
        } catch(PDOException $e) {
            $error_message = "Database error: " . $e->getMessage();
        }
    }
}
?>

<div class="page">
    <div class="container">
        <div class="row">            
            <div class="col-md-12"> 
                <?php require_once('customer-sidebar.php'); ?>
            </div>
            <div class="col-md-12">
                <div class="user-content">
                    <h3><?php echo LANG_VALUE_117; ?></h3>
                    
                    <?php if(!empty($error_message)): ?>
                        <div class="alert alert-danger"><?php echo $error_message; ?></div>
                    <?php endif; ?>
                    
                    <?php if(!empty($success_message)): ?>
                        <div class="alert alert-success"><?php echo $success_message; ?></div>
                    <?php endif; ?>
                    
                    <form action="" method="post">
                        <?php $csrf->echoInputField(); ?>
                        <div class="row">
                            <div class="col-md-6 form-group <?php echo hasError('Full Name') ? 'has-error' : ''; ?>">
                                <label><?php echo LANG_VALUE_102; ?> *</label>
                                <input type="text" class="form-control" name="cust_name" 
                                    value="<?php echo htmlspecialchars($customer['cust_name'] ?? ''); ?>" required>
                                <?php if(hasError('Full Name')): ?>
                                    <div class="error-message">Full Name should contain only characters.</div>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6 form-group <?php echo hasError('Company Name') ? 'has-error' : ''; ?>">
                                <label><?php echo LANG_VALUE_103; ?></label>
                                <input type="text" class="form-control" name="cust_cname" 
                                    value="<?php echo htmlspecialchars($customer['cust_cname'] ?? ''); ?>">
                                <?php if(hasError('Company Name')): ?>
                                    <div class="error-message">Company Name should contain only characters.</div>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6 form-group <?php echo hasError('Email') ? 'has-error' : ''; ?>">
                                <label><?php echo LANG_VALUE_94; ?> *</label>
                                <input type="text" class="form-control" 
                                    value="<?php echo htmlspecialchars($customer['cust_email'] ?? ''); ?>" disabled>
                            </div>
                            <div class="col-md-6 form-group <?php echo hasError('Phone Number') ? 'has-error' : ''; ?>">
                                <label><?php echo LANG_VALUE_104; ?> *</label>
                                <input type="text" class="form-control" name="cust_phone" 
                                    value="<?php echo htmlspecialchars($customer['cust_phone'] ?? ''); ?>" required>
                                <?php if(hasError('Phone Number')): ?>
                                    <div class="error-message">Phone number should contain only numbers.</div>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-12 form-group <?php echo hasError('Address') ? 'has-error' : ''; ?>">
                                <label><?php echo LANG_VALUE_105; ?> *</label>
                                <textarea name="cust_address" class="form-control" style="height:70px;" required><?php 
                                    echo htmlspecialchars($customer['cust_address'] ?? ''); 
                                ?></textarea>
                                <?php if(hasError('Address')): ?>
                                    <div class="error-message">Please enter your address.</div>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6 form-group <?php echo hasError('Country') ? 'has-error' : ''; ?>">
                                <label><?php echo LANG_VALUE_106; ?> *</label>
                                <select name="cust_country" class="form-control" required>
                                    <?php
                                    $statement = $pdo->prepare("SELECT * FROM tbl_country ORDER BY country_name ASC");
                                    $statement->execute();
                                    $countries = $statement->fetchAll(PDO::FETCH_ASSOC);
                                    
                                    foreach ($countries as $country) {
                                        $selected = ($country['country_id'] == ($customer['cust_country'] ?? 0)) ? 'selected' : '';
                                        echo '<option value="'.(int)$country['country_id'].'" '.$selected.'>'
                                            .htmlspecialchars($country['country_name']).'</option>';
                                    }
                                    ?>
                                </select>                                    
                                <?php if(hasError('Country')): ?>
                                    <div class="error-message">Please select your country.</div>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6 form-group <?php echo hasError('City') ? 'has-error' : ''; ?>">
                                <label><?php echo LANG_VALUE_107; ?> *</label>
                                <input type="text" class="form-control" name="cust_city" 
                                    value="<?php echo htmlspecialchars($customer['cust_city'] ?? ''); ?>" required>
                                <?php if(hasError('City')): ?>
                                    <div class="error-message">City should contain only characters.</div>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6 form-group <?php echo hasError('State') ? 'has-error' : ''; ?>">
                                <label><?php echo LANG_VALUE_108; ?> *</label>
                                <input type="text" class="form-control" name="cust_state" 
                                    value="<?php echo htmlspecialchars($customer['cust_state'] ?? ''); ?>" required>
                                <?php if(hasError('State')): ?>
                                    <div class="error-message">State should contain only characters.</div>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6 form-group <?php echo hasError('Zip Code') ? 'has-error' : ''; ?>">
                                <label><?php echo LANG_VALUE_109; ?> *</label>
                                <input type="text" class="form-control" name="cust_zip" 
                                    value="<?php echo htmlspecialchars($customer['cust_zip'] ?? ''); ?>" required>
                                <?php if(hasError('Zip Code')): ?>
                                    <div class="error-message">Zip Code should contain only numbers.</div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary" name="form1"><?php echo LANG_VALUE_5; ?></button>
                    </form>
                </div>                
            </div>
        </div>
    </div>
</div>

<style>
.has-error .form-control {
    border-color: #dc3545;
    background-color: #fff3f5;
}

.has-error .error-message {
    color: #dc3545;
    font-size: 0.875rem;
    margin-top: 0.25rem;
}

.has-error label {
    color: #dc3545;
}

/* Add a success state for valid fields */
.has-success .form-control {
    border-color: #28a745;
    background-color: #f0f9f5;
}

.has-success .error-message {
    color: #28a745;
    font-size: 0.875rem;
    margin-top: 0.25rem;
}

.has-success label {
    color: #28a745;
}
</style>

<?php require_once('footer.php'); ?>