<?php
session_start();

if(!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('location: cart.php');
    exit;
}

$product_id = (int)$_GET['id'];

if(isset($_SESSION['cart_p_id'])) {
    // Find the product in cart
    $index = array_search($product_id, $_SESSION['cart_p_id']);
    
    if($index !== false) {
        // Remove all related data
        unset($_SESSION['cart_p_id'][$index]);
        unset($_SESSION['cart_p_name'][$index]);
        unset($_SESSION['cart_p_current_price'][$index]);
        unset($_SESSION['cart_p_qty'][$index]);
        unset($_SESSION['cart_p_featured_photo'][$index]);
        unset($_SESSION['cart_size_id'][$index]);
        unset($_SESSION['cart_size_name'][$index]);
        unset($_SESSION['cart_color_id'][$index]);
        unset($_SESSION['cart_color_name'][$index]);
        
        // Re-index arrays
        $_SESSION['cart_p_id'] = array_values($_SESSION['cart_p_id']);
        $_SESSION['cart_p_name'] = array_values($_SESSION['cart_p_name']);
        $_SESSION['cart_p_current_price'] = array_values($_SESSION['cart_p_current_price']);
        $_SESSION['cart_p_qty'] = array_values($_SESSION['cart_p_qty']);
        $_SESSION['cart_p_featured_photo'] = array_values($_SESSION['cart_p_featured_photo']);
        $_SESSION['cart_size_id'] = array_values($_SESSION['cart_size_id']);
        $_SESSION['cart_size_name'] = array_values($_SESSION['cart_size_name']);
        $_SESSION['cart_color_id'] = array_values($_SESSION['cart_color_id']);
        $_SESSION['cart_color_name'] = array_values($_SESSION['cart_color_name']);
        
        $_SESSION['success_message'] = 'Product removed from cart';
    }
}

header('location: cart.php');
exit;
?>