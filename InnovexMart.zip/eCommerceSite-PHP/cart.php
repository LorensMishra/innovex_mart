<?php 
require_once('language.php');
require_once('header.php');

// Initialize cart session arrays if they don't exist
if (!isset($_SESSION['cart_p_id'])) {
    $_SESSION['cart_p_id'] = [];
    $_SESSION['cart_size_id'] = [];
    $_SESSION['cart_size_name'] = [];
    $_SESSION['cart_color_id'] = [];
    $_SESSION['cart_color_name'] = [];
    $_SESSION['cart_p_qty'] = [];
    $_SESSION['cart_p_current_price'] = [];
    $_SESSION['cart_p_name'] = [];
    $_SESSION['cart_p_featured_photo'] = [];
}

$statement = $pdo->prepare("SELECT * FROM tbl_settings WHERE id=1");
$statement->execute();
$result = $statement->fetchAll(PDO::FETCH_ASSOC);                            
foreach ($result as $row) {
    $banner_cart = $row['banner_cart'];
}

$error_message = '';
if(isset($_POST['form1'])) {
    // Get all product quantities from database
    $statement = $pdo->prepare("SELECT * FROM tbl_product");
    $statement->execute();
    $products = $statement->fetchAll(PDO::FETCH_ASSOC);
    
    $product_quantities = [];
    foreach ($products as $product) {
        $product_quantities[$product['p_id']] = $product['p_qty'];
    }

    $allow_update = 1;
    foreach ($_POST['product_id'] as $index => $product_id) {
        $quantity = $_POST['quantity'][$index];
        $product_name = $_POST['product_name'][$index];
        
        if (isset($product_quantities[$product_id])) {
            if ($product_quantities[$product_id] < $quantity) {
                $allow_update = 0;
                $error_message .= '"'.$quantity.'" items are not available for "'.$product_name.'"<br>';
            } else {
                $_SESSION['cart_p_qty'][$index] = $quantity;
            }
        }
    }
    
    if ($allow_update) {
        $error_message = 'All Items Quantity Update is Successful!';
    } else {
        $error_message .= '<br>Other items quantity were updated successfully!';
    }
    
    if (!empty($error_message)) {
        echo '<script>alert("'.str_replace(["\n", "\r"], '', $error_message).'");</script>';
    }
}
?>

<div class="page-banner" style="background-image: url(assets/uploads/<?php echo $banner_cart; ?>)">
    <div class="overlay"></div>
    <div class="page-banner-inner">
        <h1><?php echo LANG_VALUE_18; ?></h1>
    </div>
</div>

<div class="page">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php if(empty($_SESSION['cart_p_id'])): ?>
                    <h2 class="text-center">Cart is Empty!!</h2>
                    <h4 class="text-center">Add products to the cart in order to view it here.</h4>
                <?php else: ?>
                <form action="" method="post">
                    <?php $csrf->echoInputField(); ?>
                    <div class="cart">
                        <table class="table table-responsive table-hover table-bordered">
                            <tr>
                                <th><?php echo '#' ?></th>
                                <th><?php echo LANG_VALUE_8; ?></th>
                                <th><?php echo LANG_VALUE_47; ?></th>
                                <th><?php echo LANG_VALUE_157; ?></th>
                                <th><?php echo LANG_VALUE_158; ?></th>
                                <th><?php echo LANG_VALUE_159; ?></th>
                                <th><?php echo LANG_VALUE_55; ?></th>
                                <th class="text-right"><?php echo LANG_VALUE_82; ?></th>
                                <th class="text-center" style="width: 100px;"><?php echo LANG_VALUE_83; ?></th>
                            </tr>
                            <?php
                            $table_total_price = 0;
                            $cart_items = count($_SESSION['cart_p_id']);
                            
                            for ($i = 0; $i < $cart_items; $i++): 
                                $row_total_price = 0;
                                if (isset($_SESSION['cart_p_id'][$i]) && isset($_SESSION['cart_p_qty'][$i]) && isset($_SESSION['cart_p_current_price'][$i])) {
                                    $row_total_price = $_SESSION['cart_p_current_price'][$i] * $_SESSION['cart_p_qty'][$i];
                                }
                                $table_total_price += $row_total_price;
                            ?>
                            <tr>
                                <td><?php echo $i+1; ?></td>
                                <td>
                                    <?php if (isset($_SESSION['cart_p_featured_photo'][$i])): ?>
                                        <img src="assets/uploads/<?php echo $_SESSION['cart_p_featured_photo'][$i]; ?>" alt="">
                                    <?php endif; ?>
                                </td>
                                <td><?php echo $_SESSION['cart_p_name'][$i] ?? ''; ?></td>
                                <td><?php echo $_SESSION['cart_size_name'][$i] ?? ''; ?></td>
                                <td><?php echo $_SESSION['cart_color_name'][$i] ?? ''; ?></td>
                                <td><?php echo LANG_VALUE_1; ?><?php echo $_SESSION['cart_p_current_price'][$i] ?? ''; ?></td>
                                <td>
                                    <input type="hidden" name="product_id[]" value="<?php echo $_SESSION['cart_p_id'][$i] ?? ''; ?>">
                                    <input type="hidden" name="product_name[]" value="<?php echo $_SESSION['cart_p_name'][$i] ?? ''; ?>">
                                    <input type="number" class="input-text qty text" step="1" min="1" max="" 
                                           name="quantity[]" value="<?php echo $_SESSION['cart_p_qty'][$i] ?? ''; ?>" 
                                           title="Qty" size="4" pattern="[0-9]*" inputmode="numeric">
                                </td>
                                <td class="text-right">
                                    <?php echo LANG_VALUE_1; ?><?php echo $row_total_price; ?>
                                </td>
                                <td class="text-center">
                                    <a onclick="return confirmDelete();" 
                                       href="cart-item-delete.php?id=<?php echo $_SESSION['cart_p_id'][$i] ?? ''; ?>&size=<?php echo $_SESSION['cart_size_id'][$i] ?? ''; ?>&color=<?php echo $_SESSION['cart_color_id'][$i] ?? ''; ?>" 
                                       class="trash">
                                        <i class="fa fa-trash" style="color:red;"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endfor; ?>
                            <tr>
                                <th colspan="7" class="total-text">Total</th>
                                <th class="total-amount"><?php echo LANG_VALUE_1; ?><?php echo $table_total_price; ?></th>
                                <th></th>
                            </tr>
                        </table> 
                    </div>

                    <div class="cart-buttons">
                        <ul>
                            <li><input type="submit" value="<?php echo LANG_VALUE_20; ?>" class="btn btn-primary" name="form1"></li>
                            <li><a href="index.php" class="btn btn-primary"><?php echo LANG_VALUE_85; ?></a></li>
                            <li><a href="checkout.php" class="btn btn-primary"><?php echo LANG_VALUE_23; ?></a></li>
                        </ul>
                    </div>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once('footer.php'); ?>