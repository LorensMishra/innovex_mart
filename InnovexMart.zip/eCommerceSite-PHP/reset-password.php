<?php require_once('header.php'); ?>

<?php
$statement = $pdo->prepare("SELECT * FROM tbl_settings WHERE id=1");
$statement->execute();
$result = $statement->fetchAll(PDO::FETCH_ASSOC);                            
foreach ($result as $row) {
    $banner_reset_password = $row['banner_reset_password'];
}
?>

<?php
if( !isset($_GET['email']) || !isset($_GET['token']) )
{
    header('location: '.BASE_URL.'login.php');
    exit;
}

$statement = $pdo->prepare("SELECT * FROM tbl_customer WHERE cust_email=? AND cust_token=?");
$statement->execute(array($_GET['email'],$_GET['token']));
$result = $statement->fetchAll(PDO::FETCH_ASSOC);
$tot = $statement->rowCount();
if($tot == 0)
{
    header('location: '.BASE_URL.'login.php');
    exit;
}
foreach ($result as $row) {
    $saved_time = $row['cust_timestamp'];
}

$error_message2 = '';
if(time() - $saved_time > 86400)
{
    $error_message2 = "Password reset link has expired. Please request a new password reset link.";
}

if(isset($_POST['form1'])) {

    $valid = 1;
    
    // Verify current password
    if( empty($_POST['cust_current_password']) )
    {
        $valid = 0;
        $error_message = "Current password is required.";
    }
    else
    {
        // Verify current password
        $statement = $pdo->prepare("SELECT cust_password FROM tbl_customer WHERE cust_email = ?");
        $statement->execute([$_GET['email']]);
        $result = $statement->fetch(PDO::FETCH_ASSOC);
        
        if(!password_verify($_POST['cust_current_password'], $result['cust_password']))
        {
            $valid = 0;
            $error_message = "Current password is incorrect.";
        }
    }

    if( empty($_POST['cust_new_password']) || empty($_POST['cust_re_password']) )
    {
        $valid = 0;
        $error_message = "New password and confirm password are required.";
    }
    else
    {
        if($_POST['cust_new_password'] != $_POST['cust_re_password'])
        {
            $valid = 0;
            $error_message = "New password and confirm password do not match.";
        }
    }   

    if($valid == 1) {

        $new_password = $_POST['cust_new_password'];
        
        $statement = $pdo->prepare("UPDATE tbl_customer SET cust_password = ?, cust_token = '', cust_timestamp = 0 WHERE cust_email = ?");
        $statement->execute([password_hash($new_password, PASSWORD_DEFAULT), $_GET['email']]);
        
        $success_message = "Password has been successfully changed. You can now login with your new password.";
        
        header('Location: reset-password-success.php');
        exit;
    }

    
}
?>

<div class="page-banner" style="background-color:#444;background-image: url(assets/uploads/<?php echo $banner_reset_password; ?>);">
    <div class="inner">
        <h1>Reset Password</h1>
    </div>
</div>

<div class="page">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="user-content">
                    <?php
                    if($error_message != '') {
                        echo "<script>alert('".$error_message."')</script>";
                    }
                    ?>
                    <?php if($error_message2 != ''): ?>
                        <div class="error"><?php echo $error_message2; ?></div>
                    <?php else: ?>
                        <form action="" method="post">
                            <?php $csrf->echoInputField(); ?>
                            <div class="row">
                                <div class="col-md-4"></div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="">Current Password *</label>
                                        <input type="password" class="form-control" name="cust_current_password" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="">New Password *</label>
                                        <input type="password" class="form-control" name="cust_new_password" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Confirm New Password *</label>
                                        <input type="password" class="form-control" name="cust_re_password" required>
                                    </div>
                                    <div class="form-group">
                                        <label for=""></label>
                                        <input type="submit" class="btn btn-primary" value="Reset Password" name="form1">
                                    </div>
                                </div>
                            </div>                        
                        </form>
                    <?php endif; ?>
                </div>                
            </div>
        </div>
    </div>
</div>

<?php require_once('footer.php'); ?>