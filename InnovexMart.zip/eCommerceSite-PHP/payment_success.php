<?php 
require_once('header.php'); 
require_once('language.php'); 

$success_message = isset($lang_ids[121]) ? $lang_ids[121] : 'Payment Successful!'; 
?>

<div class="page">
    <div class="container">
        <div class="row">            
            <div class="col-md-12">
                <p>
                    <h3 style="margin-top:20px;"><?php echo $success_message; ?></h3>
                    <a href="dashboard.php" class="btn btn-success"><?php echo LANG_VALUE_91; ?></a>
                </p>
            </div>
        </div>
    </div>
</div>

<?php require_once('footer.php'); ?>