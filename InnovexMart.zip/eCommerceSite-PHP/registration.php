<?php 
require_once('header.php');
require_once('language.php');

// Fetch banner from database
$statement = $pdo->prepare("SELECT banner_registration FROM tbl_settings WHERE id=1");
$statement->execute();
$result = $statement->fetch(PDO::FETCH_ASSOC);
$banner_registration = $result['banner_registration'] ?? 'default-banner.jpg';

// Process registration form
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['form1'])) {
    $errors = [];
    $success_message = '';
    
    // Validation patterns
    $name_pattern = '/^[a-zA-Z \-\'\.]+$/';
    $company_pattern = '/^[a-zA-Z0-9 \-\'\.\,&]+$/';
    $address_pattern = '/^[a-zA-Z0-9 \-\'\.\,\/]+$/';
    $city_state_pattern = '/^[a-zA-Z \-\'\.]+$/';
    $zip_pattern = '/^\d+$/';
    $phone_pattern = '/^(9|8|6)\d{9}$/';
    $password_pattern = '/.*/';  // Allow any password format, depends on user preference
    
    // Sanitize and validate inputs
    $data = [
        'cust_name' => trim($_POST['cust_name'] ?? ''),
        'cust_cname' => trim($_POST['cust_cname'] ?? ''),
        'cust_email' => trim($_POST['cust_email'] ?? ''),
        'cust_phone' => trim($_POST['cust_phone'] ?? ''),
        'cust_address' => trim($_POST['cust_address'] ?? ''),
        'cust_country' => $_POST['cust_country'] ?? 0,
        'cust_city' => trim($_POST['cust_city'] ?? ''),
        'cust_state' => trim($_POST['cust_state'] ?? ''),
        'cust_zip' => trim($_POST['cust_zip'] ?? ''),
        'cust_password' => $_POST['cust_password'] ?? '',
        'cust_re_password' => $_POST['cust_re_password'] ?? '',
        'terms' => isset($_POST['terms']) ? true : false
    ];
    
    // Full Name validation
    if (empty($data['cust_name'])) {
        $errors['cust_name'] = "Full Name is required.";
    } elseif (!preg_match($name_pattern, $data['cust_name'])) {
        $errors['cust_name'] = "Full Name can only contain letters, spaces, hyphens, apostrophes, and periods.";
    }
    
    // Company Name validation
    if (!empty($data['cust_cname']) && !preg_match($company_pattern, $data['cust_cname'])) {
        $errors['cust_cname'] = "Company Name can only contain letters, numbers, spaces, hyphens, apostrophes, periods, commas, and ampersands.";
    }
    
    // Email validation
    if (empty($data['cust_email'])) {
        $errors['cust_email'] = "Email is required.";
    } elseif (!filter_var($data['cust_email'], FILTER_VALIDATE_EMAIL)) {
        $errors['cust_email'] = "Invalid email format.";
    } else {
        // Check if email exists
        $statement = $pdo->prepare("SELECT cust_id FROM tbl_customer WHERE cust_email = ?");
        $statement->execute([$data['cust_email']]);
        
        // Add debugging
        error_log("Email Check: " . $data['cust_email'] . " - Rows: " . $statement->rowCount());
        
        if ($statement->rowCount() > 0) {
            $errors['cust_email'] = LANG_VALUE_147; // Email already exists
        }
    }
    
    // Phone validation
    if (empty($data['cust_phone'])) {
        $errors['cust_phone'] = "Phone Number is required.";
    } elseif (!preg_match($phone_pattern, $data['cust_phone'])) {
        $errors['cust_phone'] = "Phone Number must be exactly 10 digits, starting with 9, 8, or 6.";
    }
    
    // Address validation
    if (empty($data['cust_address'])) {
        $errors['cust_address'] = "Address is required.";
    } elseif (!preg_match($address_pattern, $data['cust_address'])) {
        $errors['cust_address'] = "Address can only contain letters, numbers, spaces, hyphens, apostrophes, periods, commas, and slashes.";
    }
    
    // Country validation
    if (empty($data['cust_country']) || $data['cust_country'] == 0) {
        $errors['cust_country'] = "Country is required.";
    }
    
    // City validation
    if (empty($data['cust_city'])) {
        $errors['cust_city'] = "City is required.";
    } elseif (!preg_match($city_state_pattern, $data['cust_city'])) {
        $errors['cust_city'] = "City can only contain letters, spaces, hyphens, apostrophes, and periods.";
    }
    
    // State validation
    if (empty($data['cust_state'])) {
        $errors['cust_state'] = "State is required.";
    } elseif (!preg_match($city_state_pattern, $data['cust_state'])) {
        $errors['cust_state'] = "State can only contain letters, spaces, hyphens, apostrophes, and periods.";
    }
    
    // Zip Code validation
    if (empty($data['cust_zip'])) {
        $errors['cust_zip'] = "Zip Code is required.";
    } elseif (!preg_match($zip_pattern, $data['cust_zip'])) {
        $errors['cust_zip'] = "Zip Code can only contain numbers.";
    }
    
    // Password validation
    if (empty($data['cust_password'])) {
        $errors['cust_password'] = "Password is required.";
    } elseif (!preg_match($password_pattern, $data['cust_password'])) {
        $errors['cust_password'] = "Password must be at least 8 characters long and contain at least one letter, one number, and one special character (@$!%*#?&).";
    } elseif ($data['cust_password'] !== $data['cust_re_password']) {
        $errors['cust_re_password'] = "Passwords do not match.";
    }
    
    // Terms validation
    if (!$data['terms']) {
        $errors['terms'] = "You must agree to the terms and conditions.";
    }
    
    // If no errors, register user
    if (empty($errors)) {
        // Hash password
        $hashed_password = password_hash($data['cust_password'], PASSWORD_DEFAULT);
        
        // Insert user
        $statement = $pdo->prepare("INSERT INTO tbl_customer (
            cust_name, cust_cname, cust_email, cust_phone, cust_address, 
            cust_country, cust_city, cust_state, cust_zip, cust_password, 
            cust_status, cust_datetime
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, NOW())");
        
        $statement->execute([
            $data['cust_name'],
            $data['cust_cname'],
            $data['cust_email'],
            $data['cust_phone'],
            $data['cust_address'],
            $data['cust_country'],
            $data['cust_city'],
            $data['cust_state'],
            $data['cust_zip'],
            $hashed_password
        ]);
        
        // Get the new user ID
        $user_id = $pdo->lastInsertId();
        
        // Fetch the new user
        $statement = $pdo->prepare("SELECT * FROM tbl_customer WHERE cust_id = ?");
        $statement->execute([$user_id]);
        $user = $statement->fetch(PDO::FETCH_ASSOC);
        
        // Log the user in
        $_SESSION['customer'] = $user;
        
        // Set success message
        $success_message = "Registration successful! Welcome, " . htmlspecialchars($user['cust_name']) . ".";
        
        // Redirect to dashboard
        header("Location: dashboard.php");
        exit;
    }
}
?>

<style>
    .form-group {
        position: relative;
        margin-bottom: 1.5rem;
        padding: 1rem;
        border-radius: 4px;
        border: 2px solid transparent;
        transition: all 0.3s ease;
    }
    
    .form-group.valid {
        background-color: #f8f9fa;
        border-color: #28a745;
    }
    
    .form-group.invalid {
        background-color: #fff;
        border-color: #dc3545;
    }
    
    .form-group .form-control {
        border: none;
        background: transparent;
        width: 100%;
        padding: 0.5rem 0;
        border-bottom: 2px solid #ced4da;
    }
    
    .form-group.valid .form-control {
        border-bottom-color: #28a745;
    }
    
    .form-group.invalid .form-control {
        border-bottom-color: #dc3545;
    }
    
    .form-group .form-control:focus {
        outline: none;
        border-bottom-color: #007bff;
    }
    
    .form-group .invalid-feedback,
    .form-group .valid-feedback {
        position: absolute;
        bottom: -1.5rem;
        left: 0;
        display: block;
        color: #dc3545;
        font-size: 0.875rem;
        opacity: 0;
        transition: opacity 0.3s ease;
    }
    
    .form-group .valid-feedback {
        color: #28a745;
    }
    
    .form-group .form-control:focus + .invalid-feedback,
    .form-group .form-control:focus + .valid-feedback {
        opacity: 1;
    }
</style>

<div class="page-banner" style="background-color:#444;background-image: url(assets/uploads/<?= htmlspecialchars($banner_registration) ?>);">
    <div class="inner">
        <h1><?= LANG_VALUE_16 ?></h1>
    </div>
</div>

<div class="page">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="user-content">
                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                <?php foreach ($errors as $error): ?>
                                    <li><?= $error ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($success_message)): ?>
                        <div class="alert alert-success"><?= $success_message ?></div>
                    <?php endif; ?>
                    
                    <form method="post" id="registrationForm" class="needs-validation" novalidate>
                        <?php $csrf->echoInputField(); ?>
                        
                        <div class="row">
                            <div class="col-md-8 offset-md-2">
                                <h4 class="mb-4">Personal Information</h4>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <div class="form-group">
                                            <label for="cust_name" class="form-label">Full Name *</label>
                                            <input type="text" class="form-control" id="cust_name" name="cust_name" 
                                                   value="<?= htmlspecialchars($_POST['cust_name'] ?? '') ?>" 
                                                   pattern="^[a-zA-Z \-\'\.]+$" required>
                                            <div class="invalid-feedback" id="cust_name_error">
                                                Please enter your full name (letters, spaces, hyphens, apostrophes, and periods only).
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <div class="form-group">
                                            <label for="cust_cname" class="form-label">Company Name</label>
                                            <input type="text" class="form-control" id="cust_cname" name="cust_cname" 
                                                   value="<?= htmlspecialchars($_POST['cust_cname'] ?? '') ?>"
                                                   pattern="^[a-zA-Z0-9 \-\'\.\,&]+$">
                                            <div class="invalid-feedback" id="cust_cname_error">
                                                Company name can only contain letters, numbers, spaces, hyphens, apostrophes, periods, commas, and ampersands.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <div class="form-group">
                                            <label for="cust_email" class="form-label">Email *</label>
                                            <input type="email" class="form-control" id="cust_email" name="cust_email" 
                                                   value="<?= htmlspecialchars($_POST['cust_email'] ?? '') ?>" 
                                                   pattern="^[a-zA-Z0-9._%+-]+@gmail\.com$" required>
                                            <div class="invalid-feedback" id="cust_email_error">
                                                Please enter a valid Gmail address (@gmail.com required).
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <div class="form-group">
                                            <label for="cust_phone" class="form-label">Phone Number *</label>
                                            <input type="tel" class="form-control" id="cust_phone" name="cust_phone" 
                                                   value="<?= htmlspecialchars($_POST['cust_phone'] ?? '') ?>" 
                                                   pattern="^\d+$" required>
                                            <div class="invalid-feedback" id="cust_phone_error">
                                                Please enter your phone number (numbers only).
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <div class="form-group">
                                        <label for="cust_address" class="form-label">Address *</label>
                                        <textarea class="form-control" id="cust_address" name="cust_address" rows="3" 
                                                  pattern="^[a-zA-Z0-9 \-\'\.\,\/]+$" required><?= 
                                            htmlspecialchars($_POST['cust_address'] ?? '') ?></textarea>
                                        <div class="invalid-feedback" id="cust_address_error">
                                            Please enter your address (letters, numbers, spaces, hyphens, apostrophes, periods, commas, and slashes only).
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <div class="form-group">
                                            <label for="cust_country" class="form-label">Country *</label>
                                            <select class="form-select" id="cust_country" name="cust_country" required>
                                                <option value="">Select country</option>
                                                <?php
                                                $statement = $pdo->prepare("SELECT * FROM tbl_country ORDER BY country_name ASC");
                                                $statement->execute();
                                                $countries = $statement->fetchAll(PDO::FETCH_ASSOC);
                                                
                                                foreach ($countries as $country) {
                                                    $selected = ($_POST['cust_country'] ?? '') == $country['country_id'] ? 'selected' : '';
                                                    echo "<option value=\"{$country['country_id']}\" $selected>{$country['country_name']}</option>";
                                                }
                                                ?>
                                            </select>
                                            <div class="invalid-feedback" id="cust_country_error">
                                                Please select your country.
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <div class="form-group">
                                            <label for="cust_city" class="form-label">City *</label>
                                            <input type="text" class="form-control" id="cust_city" name="cust_city" 
                                                   value="<?= htmlspecialchars($_POST['cust_city'] ?? '') ?>" 
                                                   pattern="^[a-zA-Z \-\'\.]+$" required>
                                            <div class="invalid-feedback" id="cust_city_error">
                                                Please enter your city (letters, spaces, hyphens, apostrophes, and periods only).
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <div class="form-group">
                                            <label for="cust_state" class="form-label">State *</label>
                                            <div id="state_input_container">
                                                <select class="form-select" id="cust_state" name="cust_state" required>
                                                    <option value="">Select State</option>
                                                </select>
                                                <input type="text" class="form-control" id="custom_state" name="custom_state" 
                                                    style="display:none;" 
                                                    placeholder="Enter your state"
                                                    pattern="^[a-zA-Z \-\'\.]+$">
                                            </div>
                                            <div class="invalid-feedback" id="cust_state_error">
                                                Please enter your state.
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <div class="form-group">
                                            <label for="cust_zip" class="form-label">Pincode *</label>
                                            <div id="zip_input_container">
                                                <select class="form-select" id="cust_zip" name="cust_zip" required>
                                                    <option value="">Select Pincode</option>
                                                </select>
                                                <input type="text" class="form-control" id="custom_zip" name="custom_zip" 
                                                       style="display:none;" 
                                                       placeholder="Enter your Pincode"
                                                       pattern="^\d{5,6}$">
                                            </div>
                                            <div class="invalid-feedback" id="cust_zip_error">
                                                Please enter a valid Pincode.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <h4 class="mb-4 mt-5">Account Security</h4>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <div class="form-group">
                                            <label for="cust_password" class="form-label">Password *</label>
                                            <input type="password" class="form-control" id="cust_password" name="cust_password" 
                                                   pattern=".*" required>
                                            <div class="invalid-feedback" id="cust_password_error">
                                                Please enter a password.
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <div class="form-group">
                                            <label for="cust_re_password" class="form-label">Confirm Password *</label>
                                            <input type="password" class="form-control" id="cust_re_password" name="cust_re_password" required>
                                            <div class="invalid-feedback" id="cust_re_password_error">
                                                Passwords must match.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="mb-3 form-check">
                                    <div class="form-group">
                                        <input type="checkbox" class="form-check-input" id="terms" name="terms" required>
                                        <label class="form-check-label" for="terms">
                                            I agree to the <a href="terms.php" target="_blank">Terms and Conditions</a>
                                        </label>
                                        <div class="invalid-feedback" id="terms_error">
                                            You must agree to the terms and conditions.
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="d-grid gap-2">
                                    <button type="submit" name="form1" class="btn btn-primary btn-lg">
                                        <?= LANG_VALUE_15 ?>
                                    </button>
                                </div>
                                
                                <div class="mt-3 text-center">
                                    Already have an account? 
                                    <a href="login.php" class="text-decoration-none">Sign in</a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('registrationForm');
    
    // Function to validate phone number
    function validatePhoneNumber(phone) {
        // Must start with 9, 8, or 6
        // Must be exactly 10 digits
        // Cannot have more than 3 consecutive repeated digits
        const phoneRegex = /^(9|8|6)\d{9}$/;
        const repeatedDigitsRegex = /(\d)\1{3,}/;
        
        return phoneRegex.test(phone) && !repeatedDigitsRegex.test(phone);
    }

    // Function to update form group classes
    function updateFormGroupClasses(field, isValid) {
        const formGroup = field.closest('.form-group');
        if (formGroup) {
            if (isValid) {
                formGroup.classList.remove('invalid');
                formGroup.classList.add('valid');
            } else {
                formGroup.classList.remove('valid');
                formGroup.classList.add('invalid');
            }
        }
    }

    // Real-time validation
    const fields = {
        cust_name: /^[a-zA-Z \-\'\.]+$/,
        cust_cname: /^[a-zA-Z0-9 \-\'\.\,&]*$/,
        cust_email: /^[a-zA-Z0-9._%+-]+@(gmail\.com|outlook\.com|yahoo\.com|git\.com)$/,
        cust_phone: validatePhoneNumber,
        cust_address: /^[a-zA-Z0-9 \-\'\.\,\/]+$/,
        cust_country: /.+/, // Just needs to be selected
        cust_city: /^[a-zA-Z \-\'\.]+$/,
        cust_state: /^[a-zA-Z \-\'\.]+$/,
        cust_zip: /^\d{5,6}$/,
        custom_zip: /^\d{5,6}$/,
        cust_password: /.*/, // Allow any password format, depends on user preference
        terms: /true/ // Checkbox checked
    };

    // Add custom validation for custom zip input
    const customZipInput = document.getElementById('custom_zip');
    if (customZipInput) {
        customZipInput.addEventListener('input', function() {
            const isValid = /^\d{5,6}$/.test(this.value);
            updateFormGroupClasses(this, isValid);
        });
    }

    Object.keys(fields).forEach(fieldId => {
        const field = document.getElementById(fieldId);
        if (field) {
            field.addEventListener('input', function() {
                let isValid = true;
                
                // Custom validation for specific fields
                if (fieldId === 'cust_phone') {
                    isValid = fields[fieldId](field.value);
                } else {
                    // Use regex test for other fields
                    isValid = typeof fields[fieldId] === 'function' 
                        ? fields[fieldId](field.value) 
                        : fields[fieldId].test(field.value);
                }
                
                updateFormGroupClasses(field, isValid);
            });
        }
    });

    // Password match validation
    const password = document.getElementById('cust_password');
    const confirmPassword = document.getElementById('cust_re_password');
    
    if (password && confirmPassword) {
        password.addEventListener('input', validatePasswordMatch);
        confirmPassword.addEventListener('input', validatePasswordMatch);
    }

    function validatePasswordMatch() {
        const isValid = password.value === confirmPassword.value && password.value !== '';
        updateFormGroupClasses(confirmPassword, isValid);
    }
});
// Dynamic state selection
const countrySelect = document.getElementById('cust_country');
const stateSelect = document.getElementById('cust_state');
const customStateInput = document.getElementById('custom_state');

// Predefined states for India and USA
const indiaStates = [
    'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh', 
    'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand', 
    'Karnataka', 'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Manipur', 
    'Meghalaya', 'Mizoram', 'Nagaland', 'Odisha', 'Punjab', 
    'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana', 'Tripura', 
    'Uttar Pradesh', 'Uttarakhand', 'West Bengal'
];

const usStates = [
    'Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 
    'Colorado', 'Connecticut', 'Delaware', 'Florida', 'Georgia', 
    'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 
    'Kansas', 'Kentucky', 'Louisiana', 'Maine', 'Maryland', 
    'Massachusetts', 'Michigan', 'Minnesota', 'Mississippi', 'Missouri', 
    'Montana', 'Nebraska', 'Nevada', 'New Hampshire', 'New Jersey', 
    'New Mexico', 'New York', 'North Carolina', 'North Dakota', 'Ohio', 
    'Oklahoma', 'Oregon', 'Pennsylvania', 'Rhode Island', 'South Carolina', 
    'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont', 
    'Virginia', 'Washington', 'West Virginia', 'Wisconsin', 'Wyoming'
];

// Predefined Pincodes
const indiaPincodes = {
    'Andhra Pradesh': ['500001', '500002', '500003', '500004', '500005', '500006', '500007', '500008', '500009', '500010', '500011', '500012', '500013', '500014', '500015', '500016', '500017', '500018', '500019', '500020'],
    'Maharashtra': ['400001', '400002', '400003', '400004', '400005', '400006', '400007', '400008', '400009', '400010', '400011', '400012', '400013', '400014', '400015', '400016', '400017', '400018', '400019', '400020'],
    'Tamil Nadu': ['600001', '600002', '600003', '600004', '600005', '600006', '600007', '600008', '600009', '600010', '600011', '600012', '600013', '600014', '600015', '600016', '600017', '600018', '600019', '600020'],
    'Madhya Pradesh': ['462001', '462002', '462003', '462004', '462005', '462006', '462007', '462008', '462009', '462010', '462011', '462012', '462013', '462014', '462015', '462016', '462017', '462018', '462019', '462020'],
    'Karnataka': ['560001', '560002', '560003', '560004', '560005', '560006', '560007', '560008', '560009', '560010', '560011', '560012', '560013', '560014', '560015', '560016', '560017', '560018', '560019', '560020'],
    'Kerala': ['670001', '670002', '670003', '670004', '670005', '670006', '670007', '670008', '670009', '670010', '670011', '670012', '670013', '670014', '670015', '670016', '670017', '670018', '670019', '670020'],
    'Uttar Pradesh': ['226001', '226002', '226003', '226004', '226005', '226006', '226007', '226008', '226009', '226010', '226011', '226012', '226013', '226014', '226015', '211002', '211004', '212303', '211002', '211014'],
    'West Bengal': ['700001', '700002', '700003', '700004', '700005', '700006', '700007', '700008', '700009', '700010', '700011', '700012', '700013', '700014', '700015', '700016', '700017', '700018', '700019', '700020'],
    'Gujarat': ['380001', '380002', '380003', '380004', '380005', '380006', '380007', '380008', '380009', '380010', '380011', '380012', '380013', '380014', '380015', '380016', '380017', '380018', '380019', '380020'],
    'Rajasthan': ['302001', '302002', '302003', '302004', '302005', '302006', '302007', '302008', '302009', '302010', '302011', '302012', '302013', '302014', '302015', '302016', '302017', '302018', '302019', '302020'],
    'Punjab': ['160001', '160002', '160003', '160004', '160005', '160006', '160007', '160008', '160009', '160010', '160011', '160012', '160013', '160014', '160015', '160016', '160017', '160018', '160019', '160020'],
    'Telangana': ['500001', '500002', '500003', '500004', '500005', '500006', '500007', '500008', '500009', '500010', '500011', '500012', '500013', '500014', '500015', '500016', '500017', '500018', '500019', '500020']
};

const usPincodes = {
    'California': ['90001', '90002', '90003', '90004', '90005', '90006', '90007', '90008', '90009', '90010', '90011', '90012', '90013', '90014', '90015', '90016', '90017', '90018', '90019', '90020'],
    'New York': ['10001', '10002', '10003', '10004', '10005', '10006', '10007', '10008', '10009', '10010', '10011', '10012', '10013', '10014', '10015', '10016', '10017', '10018', '10019', '10020'],
    'Texas': ['75001', '75002', '75003', '75004', '75005', '75006', '75007', '75008', '75009', '75010', '75011', '75012', '75013', '75014', '75015', '75016', '75017', '75018', '75019', '75020'],
    // Add more states and their top 20 pincodes
    // ... (continue for other states)
};

// Pincode selection and validation
const zipcodeSelect = document.getElementById('cust_zip');
const customZipcodeInput = document.getElementById('custom_zip');

// Update pincode dropdown when state changes
stateSelect.addEventListener('change', function() {
    const selectedCountryOption = countrySelect.options[countrySelect.selectedIndex];
    const selectedCountryName = selectedCountryOption.text;
    const selectedState = stateSelect.value;

    // Reset zipcode selection
    zipcodeSelect.innerHTML = '<option value="">Select Pincode</option>';
    
    if (selectedCountryName === 'India' && indiaPincodes[selectedState]) {
        indiaPincodes[selectedState].forEach(pincode => {
            const option = document.createElement('option');
            option.value = pincode;
            option.textContent = pincode;
            zipcodeSelect.appendChild(option);
        });
        zipcodeSelect.style.display = 'block';
        customZipcodeInput.style.display = 'none';
    } else if (selectedCountryName === 'United States' && usPincodes[selectedState]) {
        usPincodes[selectedState].forEach(pincode => {
            const option = document.createElement('option');
            option.value = pincode;
            option.textContent = pincode;
            zipcodeSelect.appendChild(option);
        });
        zipcodeSelect.style.display = 'block';
        customZipcodeInput.style.display = 'none';
    } else {
        // For states without predefined pincodes, show custom input
        zipcodeSelect.style.display = 'none';
        customZipcodeInput.style.display = 'block';
    }
});

countrySelect.addEventListener('change', function() {
    // Reset state selection
    stateSelect.innerHTML = '<option value="">Select State</option>';
    stateSelect.style.display = 'block';
    customStateInput.style.display = 'none';
    customStateInput.value = '';

    // Reset pincode selection
    zipcodeSelect.innerHTML = '<option value="">Select Pincode</option>';
    zipcodeSelect.style.display = 'block';
    customZipcodeInput.style.display = 'none';
    customZipcodeInput.value = '';

    // Get selected country name
    const selectedCountryOption = countrySelect.options[countrySelect.selectedIndex];
    const selectedCountryName = selectedCountryOption.text;

    if (selectedCountryName === 'India') {
        // Populate India states
        indiaStates.forEach(state => {
            const option = document.createElement('option');
            option.value = state;
            option.textContent = state;
            stateSelect.appendChild(option);
        });
    } else if (selectedCountryName === 'United States') {
        // Populate US states
        usStates.forEach(state => {
            const option = document.createElement('option');
            option.value = state;
            option.textContent = state;
            stateSelect.appendChild(option);
        });
    } else {
        // For other countries, show custom state and pincode input
        stateSelect.style.display = 'none';
        customStateInput.style.display = 'block';
        
        zipcodeSelect.style.display = 'none';
        customZipcodeInput.style.display = 'block';
    }
});
</script>

function openTermsPDF() {
    // Get the absolute path to the PDF
    const pdfPath = window.location.origin + '/eCommerceSite-PHP/admin/term.pdf';
    
    // Create a new window with the PDF
    window.open(pdfPath, '_blank', 'width=800,height=600');
}
</script>

<?php require_once('footer.php'); ?>