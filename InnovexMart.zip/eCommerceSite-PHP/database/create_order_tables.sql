-- Create order status table
CREATE TABLE IF NOT EXISTS `tbl_order_status` (
  `status_id` int(11) NOT NULL AUTO_INCREMENT,
  `status_name` varchar(50) NOT NULL,
  `status_color` varchar(20) DEFAULT NULL,
  `status_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert default order statuses
INSERT INTO `tbl_order_status` (`status_name`, `status_color`, `status_order`) VALUES
('Pending', '#ffc107', 1),
('Processing', '#17a2b8', 2),
('Shipped', '#28a745', 3),
('Delivered', '#28a745', 4),
('Cancelled', '#dc3545', 5);

-- Create orders table
CREATE TABLE IF NOT EXISTS `tbl_order` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `cust_id` int(11) NOT NULL,
  `order_number` varchar(50) NOT NULL,
  `order_date` datetime NOT NULL,
  `order_status_id` int(11) NOT NULL,
  `shipping_address_id` int(11) DEFAULT NULL,
  `billing_address_id` int(11) DEFAULT NULL,
  `shipping_method` varchar(50) DEFAULT NULL,
  `shipping_cost` decimal(10,2) NOT NULL DEFAULT 0.00,
  `subtotal` decimal(10,2) NOT NULL,
  `tax` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total` decimal(10,2) NOT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_status` varchar(20) DEFAULT 'Pending',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`order_id`),
  KEY `cust_id` (`cust_id`),
  KEY `order_status_id` (`order_status_id`),
  KEY `shipping_address_id` (`shipping_address_id`),
  KEY `billing_address_id` (`billing_address_id`),
  CONSTRAINT `tbl_order_ibfk_1` FOREIGN KEY (`cust_id`) REFERENCES `tbl_customer` (`cust_id`),
  CONSTRAINT `tbl_order_ibfk_2` FOREIGN KEY (`order_status_id`) REFERENCES `tbl_order_status` (`status_id`),
  CONSTRAINT `tbl_order_ibfk_3` FOREIGN KEY (`shipping_address_id`) REFERENCES `tbl_customer_address` (`address_id`),
  CONSTRAINT `tbl_order_ibfk_4` FOREIGN KEY (`billing_address_id`) REFERENCES `tbl_customer_address` (`address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create order items table
CREATE TABLE IF NOT EXISTS `tbl_order_item` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_sku` varchar(50) DEFAULT NULL,
  `product_image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`item_id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `tbl_order_item_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `tbl_order` (`order_id`),
  CONSTRAINT `tbl_order_item_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `tbl_product` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Add indexes for better performance
ALTER TABLE `tbl_order`
  ADD INDEX `idx_order_date` (`order_date`),
  ADD INDEX `idx_order_status` (`order_status_id`);

ALTER TABLE `tbl_order_item`
  ADD INDEX `idx_order_id` (`order_id`),
  ADD INDEX `idx_product_id` (`product_id`);
