<?php
session_start();
require_once('header.php');
require_once('language.php');
?>
<!-- fetching row banner login -->
<?php
$statement = $pdo->prepare("SELECT * FROM tbl_settings WHERE id=1");
$statement->execute();
$result = $statement->fetchAll(PDO::FETCH_ASSOC);                            
foreach ($result as $row) {
    $banner_login = $row['banner_login'];
}
?>
<!-- login form -->
<?php
if (isset($_POST['form1'])) {
    $valid = 1;

    // Validate email and password
    if (empty($_POST['cust_email'])) {
        $valid = 0;
        $error_message .= "Email is required.<br>";
    }
    if (empty($_POST['cust_password'])) {
        $valid = 0;
        $error_message .= "Password is required.<br>";
    }

    // If valid, check credentials
    if ($valid == 1) {
        $email = strip_tags($_POST['cust_email']);
        $password = $_POST['cust_password'];
        
        $statement = $pdo->prepare("SELECT * FROM tbl_customer WHERE cust_email = ? AND cust_status = 1");
        $statement->execute([$email]);
        $user = $statement->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            // Verify password using password_verify
            if (password_verify($password, $user['cust_password'])) {
                // Successful login
                $_SESSION['customer'] = $user;  // Store entire user data
                $_SESSION['customer_id'] = $user['cust_id'];
                $_SESSION['customer_name'] = $user['cust_name'];
                $_SESSION['customer_cname'] = $user['cust_cname'];
                $_SESSION['customer_email'] = $user['cust_email'];
                $_SESSION['customer_logged_in'] = true;  // This is required for dashboard access
                
                // Show success message and redirect to dashboard
                $success_message = "Login successful! Redirecting to dashboard...";
                header('Refresh: 2; url=dashboard.php'); // Redirect after 2 seconds
                exit;
            } else {
                $error_message = "Incorrect password";
            }
        } else {
            $error_message = "Email not found or account inactive";
        }
    }
}
?>

<div class="page-banner" style="background-color:#444;background-image: url(assets/uploads/<?php echo $banner_login; ?>);">
    <div class="inner">
        <h1><?php echo LANG_VALUE_10; ?></h1>
    </div>
</div>

<div class="page">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="user-content">

                    
                    <form action="" method="post">
                        <?php $csrf->echoInputField(); ?>                  
                        <div class="row">
                            <div class="col-md-4"></div>
                            <div class="col-md-4">
                                <?php
                                if($error_message != '') {
                                    echo "<div class='alert alert-danger' style='padding: 10px;margin-bottom:20px;'>".$error_message."</div>";
                                }
                                if($success_message != '') {
                                    echo "<div class='alert alert-success' style='padding: 10px;margin-bottom:20px;'>".$success_message."</div>";
                                }
                                ?>
                                <div class="form-group">
                                    <label for=""><?php echo LANG_VALUE_94; ?> *</label>
                                    <input type="email" class="form-control" name="cust_email">
                                </div>
                                <div class="form-group">
                                    <label for=""><?php echo LANG_VALUE_96; ?> *</label>
                                    <input type="password" class="form-control" name="cust_password">
                                </div>
                                <div class="form-group">
                                    <label for=""></label>
                                    <input type="submit" class="btn btn-success" value="<?php echo LANG_VALUE_4; ?>" name="form1">
                                </div>
                                <a href="forget-password.php" style="color:#e4144d;"><?php echo LANG_VALUE_97; ?>?</a>
                            </div>
                        </div>                        
                    </form>
                </div>                
            </div>
        </div>
    </div>
</div>

<?php require_once('footer.php'); ?>