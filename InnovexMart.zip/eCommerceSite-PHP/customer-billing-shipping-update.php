<?php 
require_once('header.php');
require_once('language.php');

// Initialize messages
$error_message = '';
$success_message = '';

// Check if customer is logged in
if (!isset($_SESSION['customer'])) {
    header('location: '.BASE_URL.'login.php');
    exit;
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['form1'])) {
    try {
        // Validate required fields
        $required_fields = ['address_type', 'full_name', 'address_line1', 'city', 'state', 'zip_code', 'country', 'phone'];
        foreach ($required_fields as $field) {
            if (empty($_POST[$field])) {
                throw new Exception("Please fill in all required fields.");
            }
        }

        // Update session data first
        if ($_POST['address_type'] == 'Billing') {
            $_SESSION['customer']['cust_b_name'] = $_POST['full_name'];
            $_SESSION['customer']['cust_b_cname'] = $_POST['company_name'] ?? '';
            $_SESSION['customer']['cust_b_phone'] = $_POST['phone'];
            $_SESSION['customer']['cust_b_country'] = $_POST['country'];
            $_SESSION['customer']['cust_b_address'] = $_POST['address_line1'];
            $_SESSION['customer']['cust_b_city'] = $_POST['city'];
            $_SESSION['customer']['cust_b_state'] = $_POST['state'];
            $_SESSION['customer']['cust_b_zip'] = $_POST['zip_code'];
        } else {
            $_SESSION['customer']['cust_s_name'] = $_POST['full_name'];
            $_SESSION['customer']['cust_s_cname'] = $_POST['company_name'] ?? '';
            $_SESSION['customer']['cust_s_phone'] = $_POST['phone'];
            $_SESSION['customer']['cust_s_country'] = $_POST['country'];
            $_SESSION['customer']['cust_s_address'] = $_POST['address_line1'];
            $_SESSION['customer']['cust_s_city'] = $_POST['city'];
            $_SESSION['customer']['cust_s_state'] = $_POST['state'];
            $_SESSION['customer']['cust_s_zip'] = $_POST['zip_code'];
        }

        // Update database
        $statement = $pdo->prepare("UPDATE tbl_customer SET 
            cust_b_name = ?, cust_b_cname = ?, cust_b_phone = ?, cust_b_country = ?, cust_b_address = ?, cust_b_city = ?, cust_b_state = ?, cust_b_zip = ?,
            cust_s_name = ?, cust_s_cname = ?, cust_s_phone = ?, cust_s_country = ?, cust_s_address = ?, cust_s_city = ?, cust_s_state = ?, cust_s_zip = ?
            WHERE cust_id = ?");
            
        $statement->execute([
            $_SESSION['customer']['cust_b_name'], $_SESSION['customer']['cust_b_cname'], $_SESSION['customer']['cust_b_phone'], $_SESSION['customer']['cust_b_country'], 
            $_SESSION['customer']['cust_b_address'], $_SESSION['customer']['cust_b_city'], $_SESSION['customer']['cust_b_state'], $_SESSION['customer']['cust_b_zip'],
            $_SESSION['customer']['cust_s_name'], $_SESSION['customer']['cust_s_cname'], $_SESSION['customer']['cust_s_phone'], $_SESSION['customer']['cust_s_country'], 
            $_SESSION['customer']['cust_s_address'], $_SESSION['customer']['cust_s_city'], $_SESSION['customer']['cust_s_state'], $_SESSION['customer']['cust_s_zip'],
            $_SESSION['customer']['cust_id']
        ]);

        $success_message = "Address information updated successfully!";
        header('Location: checkout.php');
        exit;
    } catch (PDOException $e) {
        $error_message = "Database error: ".$e->getMessage();
    } catch (Exception $e) {
        $error_message = $e->getMessage();
    }
}

// Get countries for dropdown
$statement = $pdo->prepare("SELECT * FROM tbl_country ORDER BY country_name");
$statement->execute();
$countries = $statement->fetchAll(PDO::FETCH_ASSOC);

// Get address ID if editing
$address_id = isset($_GET['address_id']) ? $_GET['address_id'] : null;

// If editing, get existing address data
if ($address_id) {
    $statement = $pdo->prepare("SELECT * FROM tbl_customer_address WHERE address_id = ? AND cust_id = ?");
    $statement->execute([$address_id, $_SESSION['customer']['cust_id']]);
    $address = $statement->fetch(PDO::FETCH_ASSOC);
}
?>

<div class="page">
    <div class="container">
        <div class="row">            
            <div class="col-md-12"> 
                <?php require_once('customer-sidebar.php'); ?>
            </div>
            <div class="col-md-12">
                <div class="user-content">
                    <!-- Removed the box by changing the header styling -->
                    <div class="addresses-header mb-4">
                        <h2 class="mb-2"><?php echo $address_id ? 'Edit Address' : 'Add New Address'; ?></h2>
                        <p class="text-muted"><?php echo $address_id ? 'Update your address information' : 'Add a new address'; ?></p>
                    </div>

                    <?php if ($error_message): ?>
                        <div class="alert alert-danger"><?php echo $error_message; ?></div>
                    <?php endif; ?>

                    <?php if ($success_message): ?>
                        <div class="alert alert-success"><?php echo $success_message; ?></div>
                    <?php endif; ?>

                    <form action="" method="post" class="mt-4">
                        <?php $csrf->echoInputField(); ?>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="address_type">Address Type *</label>
                                    <select class="form-control" id="address_type" name="address_type" required>
                                        <option value="">Select Address Type</option>
                                        <option value="Billing" <?php echo isset($address['address_type']) && $address['address_type'] == 'Billing' ? 'selected' : ''; ?>>Billing</option>
                                        <option value="Shipping" <?php echo isset($address['address_type']) && $address['address_type'] == 'Shipping' ? 'selected' : ''; ?>>Shipping</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="full_name">Full Name *</label>
                                    <input type="text" class="form-control" id="full_name" name="full_name" 
                                        value="<?php echo isset($address['full_name']) ? htmlspecialchars($address['full_name']) : ''; ?>" required>
                                </div>

                                <div class="form-group">
                                    <label for="company_name">Company Name</label>
                                    <input type="text" class="form-control" id="company_name" name="company_name"
                                        value="<?php echo isset($address['company_name']) ? htmlspecialchars($address['company_name']) : ''; ?>">
                                </div>

                                <div class="form-group">
                                    <label for="address_line1">Address Line 1 *</label>
                                    <input type="text" class="form-control" id="address_line1" name="address_line1" 
                                        value="<?php echo isset($address['address_line1']) ? htmlspecialchars($address['address_line1']) : ''; ?>" required>
                                </div>

                                <div class="form-group">
                                    <label for="address_line2">Address Line 2</label>
                                    <input type="text" class="form-control" id="address_line2" name="address_line2"
                                        value="<?php echo isset($address['address_line2']) ? htmlspecialchars($address['address_line2']) : ''; ?>">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="city">City *</label>
                                    <input type="text" class="form-control" id="city" name="city" 
                                        value="<?php echo isset($address['city']) ? htmlspecialchars($address['city']) : ''; ?>" required>
                                </div>

                                <div class="form-group">
                                    <label for="state">State *</label>
                                    <input type="text" class="form-control" id="state" name="state" 
                                        value="<?php echo isset($address['state']) ? htmlspecialchars($address['state']) : ''; ?>" required>
                                </div>

                                <div class="form-group">
                                    <label for="zip_code">ZIP Code *</label>
                                    <input type="text" class="form-control" id="zip_code" name="zip_code" 
                                        value="<?php echo isset($address['zip_code']) ? htmlspecialchars($address['zip_code']) : ''; ?>" required>
                                </div>

                                <div class="form-group">
                                    <label for="country">Country *</label>
                                    <select class="form-control" id="country" name="country" required>
                                        <option value="">Select Country</option>
                                        <?php foreach ($countries as $country): ?>
                                            <option value="<?php echo $country['country_name']; ?>"
                                                <?php echo isset($address['country']) && $address['country'] == $country['country_name'] ? 'selected' : ''; ?>>
                                                <?php echo $country['country_name']; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="phone">Phone *</label>
                                    <input type="tel" class="form-control" id="phone" name="phone" 
                                        value="<?php echo isset($address['phone']) ? htmlspecialchars($address['phone']) : ''; ?>" required>
                                </div>

                                <div class="form-group">
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input" id="is_default" name="is_default"
                                            <?php echo isset($address['is_default']) && $address['is_default'] ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="is_default">Set as default address</label>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <button type="submit" name="form1" class="btn btn-primary">Save Address</button>
                                    <a href="addresses.php" class="btn btn-outline-secondary ml-2">Cancel</a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    /* Simplified header styling - removed the box */
    .addresses-header {
        margin-bottom: 2rem;
    }
    
    .addresses-header h2 {
        color: #2c3e50;
        font-weight: 600;
        font-size: 1.8rem;
    }
    
    .addresses-header p {
        color: #6c757d;
        font-size: 1rem;
    }
    
    /* Form styling */
    .form-group {
        margin-bottom: 1.5rem;
    }
    
    .form-control {
        border-radius: 4px;
        padding: 0.75rem;
        border: 1px solid #ced4da;
        transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    }
    
    .form-control:focus {
        border-color: #80bdff;
        outline: 0;
        box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
    }
    
    .form-check {
        margin-bottom: 1.5rem;
    }
    
    .btn {
        padding: 0.5rem 1.25rem;
        border-radius: 4px;
        font-weight: 500;
    }
    
    @media (max-width: 768px) {
        .addresses-header h2 {
            font-size: 1.5rem;
        }
        
        .col-md-6 {
            margin-bottom: 1rem;
        }
    }
</style>

<?php require_once('footer.php'); ?>