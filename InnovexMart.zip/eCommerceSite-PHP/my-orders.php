<?php require_once('header.php'); ?>

<?php
// Check if the customer is logged in or not
if(!isset($_SESSION['customer_logged_in'])) {
    header('location: login.php');
    exit;
}

// Get customer orders
$statement = $pdo->prepare("SELECT o.*, s.status_name 
                           FROM tbl_order o 
                           LEFT JOIN tbl_order_status s ON o.order_status_id = s.status_id 
                           WHERE o.cust_id = ? 
                           ORDER BY o.order_date DESC");
$statement->execute([$_SESSION['customer_id']]);
$orders = $statement->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="page">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="user-content">
                    <div class="orders-header text-center py-5 mb-5">
                        <h2 class="mb-3">My Orders</h2>
                        <p class="lead">View your order history and track your shipments</p>
                    </div>

                    <?php if (empty($orders)): ?>
                        <div class="text-center py-5">
                            <h4>No orders found</h4>
                            <p>Start shopping to place your first order!</p>
                            <a href="index.php" class="btn btn-primary">Shop Now</a>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Order ID</th>
                                        <th>Date</th>
                                        <th>Amount</th>
                                        <th>Paid Amount</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($orders as $order): ?>
                                        <tr>
                                            <td>#<?php echo $order['order_id']; ?></td>
                                            <td><?php echo date('F j, Y', strtotime($order['order_date'])); ?></td>
                                            <td>₹<?php echo number_format($order['order_total'], 2); ?></td>
                                            <td>₹<?php echo number_format($order['paid_amount'], 2); ?></td>
                                            <td>
                                                <span class="badge badge-<?php echo ($order['order_status_id'] == 1) ? 'warning' : (($order['order_status_id'] == 2) ? 'success' : 'danger'); ?>">
                                                    <?php echo $order['status_name']; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <a href="view-order.php?id=<?php echo $order['order_id']; ?>" class="btn btn-sm btn-primary">
                                                    View Details
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .orders-header {
        background: #f8f9fa;
        border-radius: 10px;
        padding: 3rem 2rem;
    }
    
    .orders-header h2 {
        color: #2c3e50;
        font-weight: 600;
    }
    
    .orders-header .lead {
        color: #666;
        font-size: 1.1rem;
    }
    
    .table {
        margin-bottom: 0;
    }
    
    .table thead th {
        background-color: #f8f9fa;
        border-bottom: 2px solid #dee2e6;
    }
    
    .badge-warning {
        background-color: #ffc107;
    }
    
    .badge-success {
        background-color: #28a745;
    }
    
    .badge-danger {
        background-color: #dc3545;
    }
    
    @media (max-width: 768px) {
        .orders-header {
            padding: 2rem 1rem;
        }
    }
</style>

<?php require_once('footer.php'); ?>
