<?php require_once('language.php'); ?>
<div class="user-sidebar">
    <div class="user-welcome">
        <?php 
        if(isset($_SESSION['customer_name'])) {
            echo '<h4>' . LANG_VALUE_89 . ', ' . $_SESSION['customer_name'] . '</h4>';
        } else {
            echo '<h4>' . LANG_VALUE_89 . '</h4>';
        }
        ?>
    </div>
    <ul>
    <a href="dashboard.php"><button class="btn btn-danger"><?php echo LANG_VALUE_89; ?></button></a>
    <a href="customer-profile-update.php"><button class="btn btn-danger"><?php echo LANG_VALUE_117; ?></button></a>
        <a href="customer-billing-shipping-update.php"><button class="btn btn-danger"><?php echo LANG_VALUE_88; ?></button></a>
        <a href="customer-password-update.php"><button class="btn btn-danger"><?php echo LANG_VALUE_99; ?></button></a>
        <a href="customer-order.php"><button class="btn btn-danger"><?php echo LANG_VALUE_24; ?></button></a>
        <a href="logout.php"><button class="btn btn-danger"><?php echo LANG_VALUE_14; ?></button></a>
    </ul>
</div>