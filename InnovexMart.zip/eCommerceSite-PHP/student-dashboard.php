<?php
session_start();
require_once('admin/inc/config.php');
require_once('header.php');

// Check if student is logged in
if (!isset($_SESSION['student_id'])) {
    header("Location: student.php");
    exit();
}
?>

<div class="container mt-5">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h4>Student Dashboard</h4>
                </div>
                <div class="card-body">
                    <h5>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h5>
                    <p>This is your student dashboard. More features coming soon.</p>
                    
                    <div class="mt-4">
                        <a href="logout.php" class="btn btn-danger">Logout</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once('footer.php'); ?>
