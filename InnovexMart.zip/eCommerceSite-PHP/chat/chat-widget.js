// Advanced Chatbot Widget
const chatMessagesDiv = document.getElementById('chatbot-messages');
const chatInput = document.getElementById('chatbot-input');
const chatSendBtn = document.getElementById('chatbot-send-btn');
const chatMicBtn = document.getElementById('chatbot-mic-btn');
const chatCloseBtn = document.getElementById('chat-close-btn');
const chatWidget = document.getElementById('chat-widget');
const chatOpenBtn = document.getElementById('chat-open-btn');

// Enhanced Message Appending
function appendMessage(response, sender) {
    const msgDiv = document.createElement('div');
    msgDiv.className = sender === 'user' ? 'user-message' : 'bot-message';
    
    // Handle different response types
    if (typeof response === 'object' && response.text) {
        // Create a temporary div to parse HTML safely
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = response.text;
        msgDiv.appendChild(tempDiv);
        
        // Add explicit links if provided
        if (response.links && response.links.length) {
            response.links.forEach(link => {
                const linkEl = document.createElement('a');
                linkEl.href = link.href;
                linkEl.textContent = link.text;
                linkEl.target = '_blank';
                linkEl.style.color = '#007bff';
                linkEl.style.textDecoration = 'underline';
                msgDiv.appendChild(document.createTextNode(' '));
                msgDiv.appendChild(linkEl);
            });
        }
    } else if (typeof response === 'string') {
        // Fallback for simple string messages
        msgDiv.textContent = response;
    }
    
    chatMessagesDiv.appendChild(msgDiv);
    chatMessagesDiv.scrollTop = chatMessagesDiv.scrollHeight;
}

// Advanced Voice Input
function setupVoiceInput() {
    if (!('webkitSpeechRecognition' in window)) {
        chatMicBtn.disabled = true;
        chatMicBtn.title = 'Voice input not supported';
        return;
    }

    const recognition = new webkitSpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onstart = () => {
        chatMicBtn.classList.add('listening');
        appendMessage('Listening... Speak now', 'bot');
    };

    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        chatInput.value = transcript;
        appendMessage(transcript, 'user');
        sendMessage(true);
    };

    recognition.onerror = (event) => {
        appendMessage(`Voice input error: ${event.error}`, 'bot');
        chatMicBtn.classList.remove('listening');
    };

    recognition.onend = () => {
        chatMicBtn.classList.remove('listening');
    };

    chatMicBtn.onclick = () => {
        try {
            recognition.start();
        } catch (error) {
            appendMessage('Could not start voice recognition', 'bot');
        }
    };
}

// Enhanced Message Sending
function sendMessage(isVoiceInput = false) {
    const message = chatInput.value.trim();
    if (!message) return;

    appendMessage(message, 'user');
    chatInput.value = '';

    fetch('/eCommerceSite-PHP/chat/process-message.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
            message: message,
            voice: isVoiceInput 
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            appendMessage(`Error: ${data.error}`, 'bot');
        } else {
            appendMessage(data.response, 'bot', true);
        }
    })
    .catch(error => {
        appendMessage('Connection error. Please try again.', 'bot');
        console.error('Chatbot error:', error);
    });
}

// Event Listeners
chatSendBtn.addEventListener('click', () => sendMessage());
chatInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') sendMessage();
});

// Initialize Voice Input
setupVoiceInput();

// Optional: First-time user greeting
if (!localStorage.getItem('chatbotGreeted')) {
    appendMessage('Hi! How can I help you today?', 'bot');
    localStorage.setItem('chatbotGreeted', '1');
}
