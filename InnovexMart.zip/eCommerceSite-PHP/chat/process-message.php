<?php
// Comprehensive Chatbot Backend
header('Content-Type: application/json');

// Error Handling and Logging
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/chatbot_errors.log');

// Input Sanitization Function
function sanitizeInput($input) {
    $input = trim($input);
    $input = strip_tags($input);
    $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
    return $input;
}

// Advanced Matching Function
function findBestMatch($query, $faq) {
    $query = strtolower(sanitizeInput($query));
    $bestMatch = null;
    $bestScore = 0;

    // Exact match
    if (isset($faq[$query])) {
        return $faq[$query];
    }

    // Partial and contextual matching
    foreach ($faq as $key => $response) {
        $lowerKey = strtolower($key);
        
        // Substring and contextual matching
        if (strpos($query, $lowerKey) !== false || 
            strpos($lowerKey, $query) !== false) {
            $score = similar_text($query, $lowerKey);
            if ($score > $bestScore) {
                $bestMatch = $response;
                $bestScore = $score;
            }
        }
    }

    return $bestMatch;
}

// Comprehensive FAQ Categories
$faq = [
    // Conversational & Greeting Messages
    "how are you" => "I'm just a bot, but I'm here to help! 😊",
    "who are you" => "I'm your friendly eCommerce assistant chatbot! 🤖",
    "thank you" => "You're welcome! If you have more questions, just ask. 🙏",
    "thanks" => "Happy to help! 😊",
    "bye" => "Goodbye! Have a great day! 👋",
    "goodbye" => "See you again soon! 👋",
    "what can you do" => "I can answer questions about orders, shipping, payments, and our policies.",
    "hello" => "Hello! How can I help you today? 👋",
    "hi" => "Hi there! 😊 How can I assist you?",
    "good morning" => "Good morning! ☀️ How can I help you?",
    "good afternoon" => "Good afternoon! 🌞 How can I help you?",
    "good evening" => "Good evening! 🌙 How can I help you?",
    "hey" => "Hello! 👋 How can I assist you today?",
    "what's up?" => "Just here to help you shop! What do you need? 😊",
    "nice to meet you" => "Likewise! Let me know if you need shopping help. 🛍️",
    "are you human?" => "Nope, I'm a smart bot here to make your shopping easier! 🤖",
    "you are helpful" => "Glad to assist! Feel free to ask more. 😊",
    "how are you" => "I'm just a bot, but I'm here to help! 😊",
    "who are you" => "I'm your friendly eCommerce assistant! 🤖",
    "thank you" => "You're welcome! Ask me anything else. 🙏",
    "hi" => "Hello! How can I help today? 👋",
    "hello" => "Hi there! What can I assist with?",
    "bye" => "Goodbye! Come back soon! 👋",
    "what can you do" => "I can help with orders, products, and policies.",
    "create account" => "Register here: <a href='register.php'>Sign Up</a>",
    "forgot password" => "Reset here: <a href='forgot-password.php'>Password Reset</a>",
    "track order" => "Share your order ID for tracking info.",
    "order status" => "Please provide your order number.",
    "return policy" => "30-day return window. Details <a href='returns.php'>here</a>",
    "refund" => "Refunds take 5-7 business days.",
    "discount code" => "Try WELCOME10 for 10% off first order!",
    "payment methods" => "We accept cards, PayPal, and Apple Pay.",
    "size guide" => "See sizes <a href='size-chart.php'>here</a>",
    "out of stock" => "Sign up for restock alerts on product page.",
    "best seller" => "Check our 'Bestsellers' section!",
    "new arrivals" => "Fresh products added weekly!",
    "price match" => "We match competitors' prices within 7 days.",
    "shipping options" => "Standard (3-5 days) or Express (1-2 days).",
    "delivery time" => "Depends on location and shipping method.",
    "free shipping" => "Free on orders over $50!",
    "international shipping" => "Available to most countries.",
    "damaged item" => "Contact support with photos for replacement.",
    "wrong item" => "We'll send the correct item - contact us!",
    "change address" => "Possible before shipment - contact us fast.",
    "cancel order" => "Cancel within 24 hours of ordering.",
    "product details" => "All specs are on the product page.",
    "authentic products" => "100% genuine items guaranteed.",
    "compare products" => "Use the 'Compare' feature on category pages.",
    "pre-order" => "Available for select items - dates vary.",
    "back in stock" => "Sign up for alerts on product page.",
    "vegan products" => "Look for the 'Vegan' badge on items.",
    "student discount" => "10% off with valid student ID.",
    "seasonal sale" => "Check our 'Sale' section for deals!",
    "gift wrapping" => "Available for $3.99 at checkout.",
    "payment secure" => "Yes! We use bank-level encryption.",
    "invoice" => "Download from order confirmation email.",
    "website down" => "Try refreshing or check back soon.",
    "page error" => "Try clearing cache or different browser.",
    "contact support" => "Email help@store.com or call 123-456-7890.",
    "live agent" => "Connecting you to human support...",
    "complaint" => "We're sorry! Please share details.",
    "feedback" => "We'd love your input! <a href='feedback.php'>Share here</a>",
    "careers" => "See openings <a href='careers.php'>here</a>",
    "blog" => "Read ours <a href='blog.php'>here</a>",
    "price?" => "Check the product page for current price.",
    "stock?" => "If available, you'll see 'Add to Cart'.",
    "coupons?" => "Check homepage for active codes.",
    "tracking?" => "Link in your shipping email.",
    "refund?" => "5-7 business days after return.",
    "exchange?" => "Within 14 days if unused.",
    "colors?" => "All options on product page.",
    "sizes?" => "See size chart on product page.",
    "delivery?" => "Usually 3-5 business days.",
    "support?" => "Email help@store.com or chat here.",
    "invoice?" => "In order confirmation email.",
    "cancel?" => "Within 24 hours of ordering.",
    "warranty?" => "1 year on most products.",
    "gift?" => "Wrapping available at checkout.",
    "deals?" => "Check our 'Sale' section!",
    "reviews?" => "On each product page.",
    "quality?" => "We guarantee high quality.",
    "location?" => "We ship from our US warehouse.",
    "hours?" => "Online store open 24/7!",
    "subscribe?" => "Sign up at bottom of homepage.",
    "tell joke" => "Why did the bot cross the road? To process your order!",
    "sing song" => "🎵 I'm a shopping bot, here to help... 🎵",
    "human?" => "Nope, just a helpful AI assistant!",
    "helpful" => "Glad to help! What else can I do?",
    "not working" => "Try refreshing or contact support.",
    "slow" => "Working faster now! What do you need?",
    "not helpful" => "Sorry! Connecting you to human agent...",
    "what's up" => "Helping customers like you! Need anything?",
    "morning" => "Good morning! Ready to shop?",
    "evening" => "Good evening! How can I help?",
    "account help" => "What do you need help with? Login, password, etc?",
    "login problem" => "Try resetting password or contact support.",
    "delete account" => "Go to Account Settings to delete.",
    "change email" => "Update in Account Settings > Profile.",
    "2FA" => "Enable in Security Settings for safety.",
    "product available?" => "Check product page for stock status.",
    "alternatives" => "Here are similar products: [link]",
    "limited edition" => "Get it before it's gone!",
    "cashback" => "Some payment methods offer cashback.",
    "price guarantee" => "We match prices within 7 days.",
    "membership" => "Join for exclusive perks!",
    "flash sale" => "Hurry - limited time offer!",
    "same day delivery" => "Available in select cities.",
    "hold order" => "Contact support before shipment.",
    "split order" => "Possible if items ship separately.",
    "signature required" => "Yes for high-value orders.",
    "return cost" => "Free for defective items.",
    "store return" => "Possible for online orders.",
    "non-returnable" => "Some items can't be returned.",
    "lost return" => "Always use tracked shipping.",
    "partial refund" => "For partial order returns.",
    "save payment" => "Option at checkout.",
    "payment failed" => "Try again or different method.",
    "PayPal issue" => "Log into PayPal and retry.",
    "BNPL" => "We accept Afterpay and Klarna.",
    "currency" => "Prices in USD. Converted at checkout.",
    "no hidden fees" => "All costs shown before payment.",
    "auto-billing" => "For subscriptions only.",
    "coupon not working" => "Check expiry and terms.",
    "secure payment" => "SSL encrypted transactions.",
    "filter" => "Use filters on category pages.",
    "wishlist" => "Save items when logged in.",
    "checkout error" => "Try again or contact support.",
    "logout issue" => "Check cookies/VPN settings.",
    "dark mode" => "In app settings only.",
    "owner" => "We're a dedicated eCommerce team!",
    "international?" => "Yes, we ship worldwide.",
    "eco-friendly" => "We use sustainable packaging.",
    "ethical" => "All suppliers vetted for fair labor.",
    "collab" => "Email partnerships@store.com",
    "voice input" => "Click mic icon and speak clearly!",
];

// Voice Input Special Handling
$voiceInputFAQ = [
    "help with voice" => "To use voice input, click the microphone icon and speak clearly. Ensure you're in a quiet environment. 🎙️",
    "microphone not working" => "Check your browser settings, microphone permissions, and ensure you're using a compatible browser like Chrome. 🔧"
];

// Error Handling and Input Processing
try {
    // Read input
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);
    
    // Validate input
    if (!$data || !isset($data['message'])) {
        throw new Exception('Invalid input');
    }

    $message = sanitizeInput($data['message']);
    $isVoiceInput = isset($data['voice']) && $data['voice'] === true;

    // Determine response source based on input type
    $responseSource = $isVoiceInput ? $voiceInputFAQ : $faq;

    // Find best match
    $response = findBestMatch($message, $responseSource);

    // Fallback mechanism
    if (!$response) {
        $fallbackResponses = [
            "I'm not sure I understand. Could you rephrase that?",
            "Sorry, I didn't catch that. Can you be more specific?",
            "I'm still learning. Could you try asking differently?"
        ];
        $response = $fallbackResponses[array_rand($fallbackResponses)];
    }

    // Log successful interactions
    error_log("Query: $message | Response: $response");

    // Send response
    echo json_encode([
        'response' => $response,
        'voice' => $isVoiceInput
    ]);

} catch (Exception $e) {
    // Comprehensive error handling
    error_log("Chatbot Error: " . $e->getMessage());
    echo json_encode([
        'error' => 'An unexpected error occurred.',
        'details' => $e->getMessage()
    ]);
}
exit;
?>
