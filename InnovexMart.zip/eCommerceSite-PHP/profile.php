<?php require_once('header.php'); ?>

<?php
// Check if the customer is logged in or not
if(!isset($_SESSION['customer_logged_in'])) {
    header('location: login.php');
    exit;
}

// Get customer details
$statement = $pdo->prepare("SELECT * FROM tbl_customer WHERE cust_id = ?");
$statement->execute([$_SESSION['customer_id']]);
$user = $statement->fetch(PDO::FETCH_ASSOC);
?>

<div class="page">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="user-content">
                    <div class="profile-header text-center py-5 mb-5">
                        <h2 class="mb-3">My Profile</h2>
                        <p class="lead">View and update your account information</p>
                    </div>

                    <div class="row">
                        <!-- Personal Information -->
                        <div class="col-md-6 mb-4">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title mb-4">Personal Information</h5>
                                    <div class="profile-info">
                                        <div class="form-group">
                                            <label>Full Name</label>
                                            <p><?php echo htmlspecialchars($user['cust_name']); ?></p>
                                        </div>
                                        <div class="form-group">
                                            <label>Company Name</label>
                                            <p><?php echo htmlspecialchars($user['cust_cname']); ?></p>
                                        </div>
                                        <div class="form-group">
                                            <label>Email Address</label>
                                            <p><?php echo htmlspecialchars($user['cust_email']); ?></p>
                                        </div>
                                        <div class="form-group">
                                            <label>Phone Number</label>
                                            <p><?php echo htmlspecialchars($user['cust_phone']); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Address Information -->
                        <div class="col-md-6 mb-4">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title mb-4">Address Information</h5>
                                    <div class="profile-info">
                                        <div class="form-group">
                                            <label>Address</label>
                                            <p><?php echo htmlspecialchars($user['cust_address']); ?></p>
                                        </div>
                                        <div class="form-group">
                                            <label>City</label>
                                            <p><?php echo htmlspecialchars($user['cust_city']); ?></p>
                                        </div>
                                        <div class="form-group">
                                            <label>State</label>
                                            <p><?php echo htmlspecialchars($user['cust_state']); ?></p>
                                        </div>
                                        <div class="form-group">
                                            <label>Zip Code</label>
                                            <p><?php echo htmlspecialchars($user['cust_zip']); ?></p>
                                        </div>
                                        <div class="form-group">
                                            <label>Country</label>
                                            <p><?php echo htmlspecialchars($user['cust_country']); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Action Buttons -->
                        <div class="col-md-12 text-center mt-4">
                            <a href="edit-profile.php" class="btn btn-primary mr-3">Edit Profile</a>
                            <a href="generate-password-token.php" class="btn btn-secondary">Change Password</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .profile-header {
        background: #f8f9fa;
        border-radius: 10px;
        padding: 3rem 2rem;
    }
    
    .profile-header h2 {
        color: #2c3e50;
        font-weight: 600;
    }
    
    .profile-header .lead {
        color: #666;
        font-size: 1.1rem;
    }
    
    .profile-info .form-group {
        margin-bottom: 1.5rem;
    }
    
    .profile-info label {
        display: block;
        font-weight: 500;
        color: #2c3e50;
        margin-bottom: 0.5rem;
    }
    
    .profile-info p {
        margin: 0;
        color: #666;
        font-size: 1rem;
    }
    
    .card {
        border: none;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        margin-bottom: 1.5rem;
    }
    
    @media (max-width: 768px) {
        .profile-header {
            padding: 2rem 1rem;
        }
        
        .profile-info .form-group {
            margin-bottom: 1rem;
        }
    }
</style>

<?php require_once('footer.php'); ?>
