<?php
require_once('header.php');

// Check if customer is logged in
if (!isset($_SESSION['customer_logged_in'])) {
    header('location: login.php');
    exit;
}

try {
    // Generate a new token
    $token = bin2hex(random_bytes(32));
    
    // Update the customer's token and timestamp
    $statement = $pdo->prepare("UPDATE tbl_customer SET cust_token = ?, cust_timestamp = ? WHERE cust_id = ?");
    $statement->execute([$token, time(), $_SESSION['customer_id']]);
    
    // Get the customer's email
    $statement = $pdo->prepare("SELECT cust_email FROM tbl_customer WHERE cust_id = ?");
    $statement->execute([$_SESSION['customer_id']]);
    $user = $statement->fetch(PDO::FETCH_ASSOC);
    
    // Redirect to reset-password.php with the new token
    header('location: reset-password.php?email=' . urlencode($user['cust_email']) . '&token=' . $token);
    exit;
} catch (PDOException $e) {
    $_SESSION['error_message'] = "An error occurred while generating the password reset link. Please try again later.";
    header('location: profile.php');
    exit;
}
?>
