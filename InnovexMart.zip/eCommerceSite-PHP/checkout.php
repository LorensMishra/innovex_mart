<?php require_once('header.php'); 
require_once('language.php');

// Initialize language array
$i=0;
$statement = $pdo->prepare("SELECT * FROM tbl_language");
$statement->execute();
$result = $statement->fetchAll(PDO::FETCH_ASSOC);							
foreach ($result as $row) {
    $i++;
    $lang_ids[$i] = $row['lang_value'];
}

$statement = $pdo->prepare("SELECT * FROM tbl_settings WHERE id=1");
$statement->execute();
$result = $statement->fetchAll(PDO::FETCH_ASSOC);                            
foreach ($result as $row) {
    $banner_checkout = $row['banner_checkout'];
}
?>

<?php
if(!isset($_SESSION['cart_p_id'])) {
    header('location: cart.php');
    exit;
}
?>

<div class="page-banner" style="background-image: url(assets/uploads/<?php echo $banner_checkout; ?>)">
    <div class="overlay"></div>
    <div class="page-banner-inner">
        <h1><?php echo $lang_ids[22]; ?></h1>
    </div>
</div>

<div class="page">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                
                <?php if(!isset($_SESSION['customer'])): ?>
                    <p>
                        <a href="login.php" class="btn btn-md btn-danger"><?php echo isset($lang_ids[160]) ? $lang_ids[160] : 'Login'; ?></a>
                    </p>
                <?php else: ?>

                <h3 class="special"><?php echo $lang_ids[26]; ?></h3>
                <div class="cart">
                    <table class="table table-responsive table-hover table-bordered">
                        <tr>
                            <th><?php echo '#' ?></th>
                            <th><?php echo $lang_ids[8]; ?></th>
                            <th><?php echo $lang_ids[47]; ?></th>
                            <th><?php echo isset($lang_ids[157]) ? $lang_ids[157] : 'Size'; ?></th>
                            <th><?php echo isset($lang_ids[158]) ? $lang_ids[158] : 'Color'; ?></th>
                            <th><?php echo isset($lang_ids[159]) ? $lang_ids[159] : 'Quantity'; ?></th>
                            <th><?php echo $lang_ids[55]; ?></th>
                            <th class="text-right"><?php echo $lang_ids[82]; ?></th>
                        </tr>
                         <?php
                        $table_total_price = 0;

                        // Initialize arrays with session data
                        $arr_cart_p_id = array();
                        $arr_cart_size_id = array();
                        $arr_cart_color_id = array();
                        $arr_cart_p_qty = array();
                        $arr_cart_p_current_price = array();
                        $arr_cart_p_name = array();
                        $arr_cart_p_featured_photo = array();
                        $arr_cart_size_name = array();
                        $arr_cart_color_name = array();

                        // Get product IDs
                        $i = 0;
                        foreach($_SESSION['cart_p_id'] as $key => $value) {
                            $i++;
                            $arr_cart_p_id[$i] = $value;
                        }

                        // Check if cart size/color arrays exist before looping
                        $cart_size_id = isset($_SESSION['cart_size_id']) ? $_SESSION['cart_size_id'] : [];
                        $cart_size_name = isset($_SESSION['cart_size_name']) ? $_SESSION['cart_size_name'] : [];
                        $cart_color_id = isset($_SESSION['cart_color_id']) ? $_SESSION['cart_color_id'] : [];
                        $cart_color_name = isset($_SESSION['cart_color_name']) ? $_SESSION['cart_color_name'] : [];

                        // Get size IDs and names
                        $i = 0;
                        foreach($cart_size_id as $key => $value) {
                            $i++;
                            $arr_cart_size_id[$i] = $value;
                        }
                        
                        $i = 0;
                        foreach($cart_size_name as $key => $value) {
                            $i++;
                            $arr_cart_size_name[$i] = $value;
                        }

                        // Get color IDs and names
                        $i = 0;
                        foreach($cart_color_id as $key => $value) {
                            $i++;
                            $arr_cart_color_id[$i] = $value;
                        }
                        
                        $i = 0;
                        foreach($cart_color_name as $key => $value) {
                            $i++;
                            $arr_cart_color_name[$i] = $value;
                        }

                        // Get quantities
                        $i = 0;
                        foreach($_SESSION['cart_p_qty'] as $key => $value) {
                            $i++;
                            $arr_cart_p_qty[$i] = $value;
                        }

                        // Get prices
                        $i = 0;
                        foreach($_SESSION['cart_p_current_price'] as $key => $value) {
                            $i++;
                            $arr_cart_p_current_price[$i] = $value;
                        }

                        // Get product names
                        $i = 0;
                        foreach($_SESSION['cart_p_name'] as $key => $value) {
                            $i++;
                            $arr_cart_p_name[$i] = $value;
                        }

                        // Get product photos
                        $i = 0;
                        foreach($_SESSION['cart_p_featured_photo'] as $key => $value) {
                            $i++;
                            $arr_cart_p_featured_photo[$i] = $value;
                        }
                        ?>
                        <?php for ($i = 0; $i < count($arr_cart_p_id); $i++): ?>
                        <tr>
                            <td><?php echo $i+1; ?></td>
                            <td>
                                <img src="assets/uploads/<?php echo $arr_cart_p_featured_photo[$i+1]; ?>" alt="" style="width:100px;">
                                <br>
                                <?php echo $arr_cart_p_name[$i+1]; ?>
                            </td>
                            <td>₹<?php echo $arr_cart_p_current_price[$i+1]; ?></td>
                            <td>
                                <?php 
                                if(isset($arr_cart_size_name[$i+1])) {
                                    echo $arr_cart_size_name[$i+1];
                                }
                                ?>
                            </td>
                            <td>
                                <?php 
                                if(isset($arr_cart_color_name[$i+1])) {
                                    echo $arr_cart_color_name[$i+1];
                                }
                                ?>
                            </td>
                            <td>
                                <?php 
                                if(isset($arr_cart_p_qty[$i+1])) {
                                    echo $arr_cart_p_qty[$i+1];
                                }
                                ?>
                            </td>
                            <td class="text-right">
                                <?php
                                $row_total_price = 0;
                                if(isset($arr_cart_p_current_price[$i+1]) && isset($arr_cart_p_qty[$i+1])) {
                                    $row_total_price = $arr_cart_p_current_price[$i+1] * $arr_cart_p_qty[$i+1];
                                }
                                $table_total_price = $table_total_price + $row_total_price;
                                ?>
                                ₹<?php echo $row_total_price; ?>
                            </td>
                        </tr>
                        <?php endfor; ?>           
                        <tr>
                            <th colspan="7" class="total-text"><?php echo $lang_ids[81]; ?></th>
                            <th class="total-amount">₹<?php echo $table_total_price; ?></th>
                        </tr>
                        <?php
                        $statement = $pdo->prepare("SELECT * FROM tbl_shipping_cost WHERE country_id=?");
                        $statement->execute(array($_SESSION['customer']['cust_country']));
                        $total = $statement->rowCount();
                        if($total) {
                            $result = $statement->fetchAll(PDO::FETCH_ASSOC);
                            foreach ($result as $row) {
                                $shipping_cost = $row['amount'];
                            }
                        } else {
                            $statement = $pdo->prepare("SELECT * FROM tbl_shipping_cost_all WHERE sca_id=1");
                            $statement->execute();
                            $result = $statement->fetchAll(PDO::FETCH_ASSOC);
                            foreach ($result as $row) {
                                $shipping_cost = $row['amount'];
                            }
                        }                        
                        ?>
                        <tr>
                            <td colspan="7" class="total-text"><?php echo $lang_ids[84]; ?></td>
                            <td class="total-amount">₹<?php echo $shipping_cost; ?></td>
                        </tr>
                        <tr>
                            <th colspan="7" class="total-text"><?php echo $lang_ids[82]; ?></th>
                            <th class="total-amount">
                                <?php
                                $final_total = $table_total_price+$shipping_cost;
                                ?>
                                ₹<?php echo $final_total; ?>
                            </th>
                        </tr>
                    </table> 
                </div>

                <?php if (isset($error_message)): ?>
                <div class="alert alert-danger"><?php echo $error_message; ?></div>
                <?php endif; ?>
                <?php if (isset($success_message)): ?>
                <div class="alert alert-success"><?php echo $success_message; ?></div>
                <?php endif; ?>

                <div class="billing-address">
                    <div class="row">
                        <div class="col-md-6">
                            <h3 class="special"><?php echo isset($lang_ids[161]) ? $lang_ids[161] : 'Billing Address'; ?></h3>
                            <?php if(isset($_SESSION['customer'])): ?>
                            <?php if(empty($_SESSION['customer']['cust_b_name'])): ?>
                                <div class="alert alert-warning">Billing address not set</div>
                            <?php endif; ?>
                            <table class="table table-responsive table-bordered table-hover table-striped bill-address">
                                <tr>
                                    <td><?php echo isset($lang_ids[102]) ? $lang_ids[102] : 'Name'; ?></td>
                                    <td><?php echo isset($_SESSION['customer']['cust_b_name']) ? $_SESSION['customer']['cust_b_name'] : ''; ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo isset($lang_ids[103]) ? $lang_ids[103] : 'Company Name'; ?></td>
                                    <td><?php echo isset($_SESSION['customer']['cust_b_cname']) ? $_SESSION['customer']['cust_b_cname'] : ''; ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo isset($lang_ids[104]) ? $lang_ids[104] : 'Phone Number'; ?></td>
                                    <td><?php echo isset($_SESSION['customer']['cust_b_phone']) ? $_SESSION['customer']['cust_b_phone'] : ''; ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo isset($lang_ids[105]) ? $lang_ids[105] : 'Country'; ?></td>
                                    <td>
                                        <?php
                                        if(isset($_SESSION['customer']['cust_b_country'])) {
                                            echo $_SESSION['customer']['cust_b_country'];
                                        }
                                        ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td><?php echo isset($lang_ids[106]) ? $lang_ids[106] : 'Address'; ?></td>
                                    <td>
                                        <?php 
                                        if(isset($_SESSION['customer']['cust_b_address'])) {
                                            echo nl2br($_SESSION['customer']['cust_b_address']); 
                                        }
                                        ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td><?php echo isset($lang_ids[107]) ? $lang_ids[107] : 'City'; ?></td>
                                    <td><?php echo isset($_SESSION['customer']['cust_b_city']) ? $_SESSION['customer']['cust_b_city'] : ''; ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo isset($lang_ids[108]) ? $lang_ids[108] : 'State'; ?></td>
                                    <td><?php echo isset($_SESSION['customer']['cust_b_state']) ? $_SESSION['customer']['cust_b_state'] : ''; ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo isset($lang_ids[109]) ? $lang_ids[109] : 'Zip Code'; ?></td>
                                    <td><?php echo isset($_SESSION['customer']['cust_b_zip']) ? $_SESSION['customer']['cust_b_zip'] : ''; ?></td>
                                </tr>
                            </table>
                            <a href="customer-billing-shipping-update.php?type=billing" class="btn btn-primary">
                                <?php echo isset($lang_ids[110]) ? $lang_ids[110] : 'Update Billing Address'; ?>
                            </a>
                            <?php else: ?>
                            <p class="text-muted">Please log in to view billing address.</p>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <h3 class="special"><?php echo isset($lang_ids[162]) ? $lang_ids[162] : 'Shipping Address'; ?></h3>
                            <?php if(isset($_SESSION['customer'])): ?>
                            <?php if(empty($_SESSION['customer']['cust_s_name'])): ?>
                                <div class="alert alert-warning">Shipping address not set</div>
                            <?php endif; ?>
                            <table class="table table-responsive table-bordered table-hover table-striped bill-address">
                                <tr>
                                    <td><?php echo isset($lang_ids[102]) ? $lang_ids[102] : 'Name'; ?></td>
                                    <td><?php echo isset($_SESSION['customer']['cust_s_name']) ? $_SESSION['customer']['cust_s_name'] : ''; ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo isset($lang_ids[103]) ? $lang_ids[103] : 'Company Name'; ?></td>
                                    <td><?php echo isset($_SESSION['customer']['cust_s_cname']) ? $_SESSION['customer']['cust_s_cname'] : ''; ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo isset($lang_ids[104]) ? $lang_ids[104] : 'Phone Number'; ?></td>
                                    <td><?php echo isset($_SESSION['customer']['cust_s_phone']) ? $_SESSION['customer']['cust_s_phone'] : ''; ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo isset($lang_ids[105]) ? $lang_ids[105] : 'Country'; ?></td>
                                    <td>
                                        <?php
                                        if(isset($_SESSION['customer']['cust_s_country'])) {
                                            echo $_SESSION['customer']['cust_s_country'];
                                        }
                                        ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td><?php echo isset($lang_ids[106]) ? $lang_ids[106] : 'Address'; ?></td>
                                    <td>
                                        <?php 
                                        if(isset($_SESSION['customer']['cust_s_address'])) {
                                            echo nl2br($_SESSION['customer']['cust_s_address']); 
                                        }
                                        ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td><?php echo isset($lang_ids[107]) ? $lang_ids[107] : 'City'; ?></td>
                                    <td><?php echo isset($_SESSION['customer']['cust_s_city']) ? $_SESSION['customer']['cust_s_city'] : ''; ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo isset($lang_ids[108]) ? $lang_ids[108] : 'State'; ?></td>
                                    <td><?php echo isset($_SESSION['customer']['cust_s_state']) ? $_SESSION['customer']['cust_s_state'] : ''; ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo isset($lang_ids[109]) ? $lang_ids[109] : 'Zip Code'; ?></td>
                                    <td><?php echo isset($_SESSION['customer']['cust_s_zip']) ? $_SESSION['customer']['cust_s_zip'] : ''; ?></td>
                                </tr>
                            </table>
                            <a href="customer-billing-shipping-update.php?type=shipping" class="btn btn-primary">
                                <?php echo isset($lang_ids[110]) ? $lang_ids[110] : 'Update Shipping Address'; ?>
                            </a>
                            <?php else: ?>
                            <p class="text-muted">Please log in to view shipping address.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="cart-buttons">
                    <ul>
                        <li><a href="cart.php" class="btn btn-primary"><?php echo $lang_ids[21]; ?></a></li>
                    </ul>
                </div>

				<div class="clear"></div>
                <h3 class="special"><?php echo $lang_ids[33]; ?></h3>
                <div class="row">
                    
                    	<?php
		                $checkout_access = 1;
		                if(
		                    ($_SESSION['customer']['cust_b_name']=='') ||
		                    ($_SESSION['customer']['cust_b_cname']=='') ||
		                    ($_SESSION['customer']['cust_b_phone']=='') ||
		                    ($_SESSION['customer']['cust_b_country']=='') ||
		                    ($_SESSION['customer']['cust_b_address']=='') ||
		                    ($_SESSION['customer']['cust_b_city']=='') ||
		                    ($_SESSION['customer']['cust_b_state']=='') ||
		                    ($_SESSION['customer']['cust_b_zip']=='') ||
		                    ($_SESSION['customer']['cust_s_name']=='') ||
		                    ($_SESSION['customer']['cust_s_cname']=='') ||
		                    ($_SESSION['customer']['cust_s_phone']=='') ||
		                    ($_SESSION['customer']['cust_s_country']=='') ||
		                    ($_SESSION['customer']['cust_s_address']=='') ||
		                    ($_SESSION['customer']['cust_s_city']=='') ||
		                    ($_SESSION['customer']['cust_s_state']=='') ||
		                    ($_SESSION['customer']['cust_s_zip']=='')
		                ) {
		                    $checkout_access = 0;
		                }
		                ?>
		                <?php if($checkout_access == 0): ?>
		                	<div class="col-md-12">
				                <div style="color:red;font-size:22px;margin-bottom:50px;">
			                        You must have to fill up all the billing and shipping information from your dashboard panel in order to checkout the order. Please fill up the information going to <a href="customer-billing-shipping-update.php" style="color:red;text-decoration:underline;">this link</a>.
			                    </div>
	                    	</div>
	                	<?php else: ?>
		                	<div class="col-md-4">
		                		
	                            <div class="row">

	                                <div class="col-md-12 form-group">
	                                    <label for=""><?php echo $lang_ids[34]; ?> *</label>
	                                    <select name="payment_method" class="form-control select2" id="advFieldsStatus">
	                                        <option value=""><?php echo $lang_ids[35]; ?></option>
	                                        <option value="PayPal"><?php echo $lang_ids[36]; ?></option>
	                                        <option value="Bank Deposit"><?php echo $lang_ids[38]; ?></option>
	                                    </select>
	                                </div>

                                    <form class="paypal" action="<?php echo BASE_URL; ?>payment/paypal/payment_process.php" method="post" id="paypal_form" target="_blank">
                                        <input type="hidden" name="cmd" value="_xclick" />
                                        <input type="hidden" name="no_note" value="1" />
                                        <input type="hidden" name="lc" value="UK" />
                                        <input type="hidden" name="currency_code" value="USD" />
                                        <input type="hidden" name="bn" value="PP-BuyNowBF:btn_buynow_LG.gif:NonHostedGuest" />

                                        <input type="hidden" name="final_total" value="<?php echo $final_total; ?>">
                                        <div class="col-md-12 form-group">
                                            <input type="submit" class="btn btn-primary" value="<?php echo $lang_ids[46]; ?>" name="form1">
                                        </div>
                                    </form>



                                    <form action="payment/bank/init.php" method="post" id="bank_form">
                                        <input type="hidden" name="amount" value="<?php echo $final_total; ?>">
                                        <div class="col-md-12 form-group">
                                            <label for=""><?php echo $lang_ids[43]; ?></span></label><br>
                                            <?php
                                            $statement = $pdo->prepare("SELECT * FROM tbl_settings WHERE id=1");
                                            $statement->execute();
                                            $result = $statement->fetchAll(PDO::FETCH_ASSOC);
                                            foreach ($result as $row) {
                                                echo nl2br($row['bank_detail']);
                                            }
                                            ?>
                                        </div>
                                        <div class="col-md-12 form-group">
                                            <label for=""><?php echo $lang_ids[44]; ?> <br><span style="font-size:12px;font-weight:normal;">(<?php echo $lang_ids[45]; ?>)</span></label>
                                            <textarea name="transaction_info" class="form-control" cols="30" rows="10"></textarea>
                                        </div>
                                        <div class="col-md-12 form-group">
                                            <input type="submit" class="btn btn-primary" value="<?php echo $lang_ids[46]; ?>" name="form3">
                                        </div>
                                    </form>
	                                
	                            </div>
		                            
		                        
		                    </div>
		                <?php endif; ?>
                        
                </div>
                

                <?php endif; ?>

            </div>
        </div>
    </div>
</div>


<?php require_once('footer.php'); ?>