<?php require_once('header.php'); ?>

<?php
// Check if customer is logged in
if (!isset($_SESSION['customer_logged_in'])) {
    header('location: login.php');
    exit;
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['form1'])) {
    try {
        // Validate required fields
        $required_fields = ['address_type', 'full_name', 'address_line1', 'city', 'state', 'zip_code', 'country', 'phone'];
        foreach ($required_fields as $field) {
            if (empty($_POST[$field])) {
                throw new Exception("Please fill in all required fields.");
            }
        }

        // Prepare insert statement
        $statement = $pdo->prepare("
            INSERT INTO tbl_customer_address (
                cust_id,
                address_type,
                full_name,
                company_name,
                address_line1,
                address_line2,
                city,
                state,
                zip_code,
                country,
                phone,
                is_default
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        // Execute insert
        $statement->execute([
            $_SESSION['customer_id'],
            $_POST['address_type'],
            $_POST['full_name'],
            $_POST['company_name'] ?? '',
            $_POST['address_line1'],
            $_POST['address_line2'] ?? '',
            $_POST['city'],
            $_POST['state'],
            $_POST['zip_code'],
            $_POST['country'],
            $_POST['phone'],
            isset($_POST['is_default']) ? 1 : 0
        ]);

        // If this is set as default, update other addresses
        if (isset($_POST['is_default'])) {
            $statement = $pdo->prepare("UPDATE tbl_customer_address SET is_default = 0 WHERE cust_id = ? AND address_id != LAST_INSERT_ID()");
            $statement->execute([$_SESSION['customer_id']]);
        }

        // Redirect to addresses page with success message
        $_SESSION['success_message'] = "Address added successfully!";
        header('Location: addresses.php');
        exit;
    } catch (PDOException $e) {
        $error_message = "An error occurred while updating the address. Please try again later.";
    } catch (Exception $e) {
        $error_message = $e->getMessage();
    }
}

// Get countries for dropdown
$statement = $pdo->prepare("SELECT * FROM tbl_country ORDER BY country_name");
$statement->execute();
$countries = $statement->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="page">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="user-content">
                    <div class="addresses-header text-center py-5 mb-5">
                        <h2 class="mb-3">Add New Address</h2>
                        <p class="lead">Add a new shipping or billing address</p>
                    </div>

                    <?php if (isset($error_message)): ?>
                    <div class="alert alert-danger">
                        <?php echo $error_message; ?>
                    </div>
                    <?php endif; ?>

                    <div class="card">
                        <div class="card-body">
                            <form action="" method="post">
                                <?php $csrf->echoInputField(); ?>
                                
                                <div class="form-group">
                                    <label for="address_type">Address Type *</label>
                                    <select class="form-control" id="address_type" name="address_type" required>
                                        <option value="">Select Address Type</option>
                                        <option value="Billing">Billing</option>
                                        <option value="Shipping">Shipping</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="full_name">Full Name *</label>
                                    <input type="text" class="form-control" id="full_name" name="full_name" required>
                                </div>

                                <div class="form-group">
                                    <label for="company_name">Company Name</label>
                                    <input type="text" class="form-control" id="company_name" name="company_name">
                                </div>

                                <div class="form-group">
                                    <label for="address_line1">Address Line 1 *</label>
                                    <input type="text" class="form-control" id="address_line1" name="address_line1" required>
                                </div>

                                <div class="form-group">
                                    <label for="address_line2">Address Line 2</label>
                                    <input type="text" class="form-control" id="address_line2" name="address_line2">
                                </div>

                                <div class="form-group">
                                    <label for="city">City *</label>
                                    <input type="text" class="form-control" id="city" name="city" required>
                                </div>

                                <div class="form-group">
                                    <label for="state">State *</label>
                                    <input type="text" class="form-control" id="state" name="state" required>
                                </div>

                                <div class="form-group">
                                    <label for="zip_code">ZIP Code *</label>
                                    <input type="text" class="form-control" id="zip_code" name="zip_code" required>
                                </div>

                                <div class="form-group">
                                    <label for="country">Country *</label>
                                    <select class="form-control" id="country" name="country" required>
                                        <option value="">Select Country</option>
                                        <?php foreach ($countries as $country): ?>
                                            <option value="<?php echo $country['country_name']; ?>">
                                                <?php echo $country['country_name']; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="phone">Phone *</label>
                                    <input type="tel" class="form-control" id="phone" name="phone" required>
                                </div>

                                <div class="form-group">
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input" id="is_default" name="is_default">
                                        <label class="form-check-label" for="is_default">Set as default address</label>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <button type="submit" name="form1" class="btn btn-primary">Save Address</button>
                                    <a href="addresses.php" class="btn btn-secondary">Cancel</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once('footer.php'); ?>
