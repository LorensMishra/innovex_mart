<?php
require_once 'header.php';
require_once 'language.php';
?>

<div class="page">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="user-content">
                    <h1 class="text-center mb-4">InnovexMart Terms and Conditions</h1>
                    <p class="text-center text-muted mb-5">Last Updated: <?= date('F j, Y') ?></p>
                    
                    <div class="terms-content">
                        <div class="alert alert-info">
                            <strong>Important:</strong> Please read these Terms and Conditions carefully before using our website or purchasing our products.
                        </div>

                        <h3>1. Introduction</h3>
                        <p>Welcome to InnovexMart ("we," "our," or "us"). These Terms and Conditions govern your use of our eCommerce platform (www.innovexmart.com) and all purchases made through it. By accessing or using our website, you agree to be bound by these terms.</p>

                        <h3>2. Account Registration</h3>
                        <ul>
                            <li>You must be at least 18 years old to create an account and make purchases</li>
                            <li>You are responsible for maintaining the confidentiality of your account credentials</li>
                            <li>All registration information must be accurate and current</li>
                            <li>We reserve the right to suspend or terminate accounts that violate these terms</li>
                        </ul>

                        <h3>3. Product Information</h3>
                        <p>InnovexMart specializes in electronics and tech products. While we strive for accuracy:</p>
                        <ul>
                            <li>Product descriptions, images, and specifications are subject to change</li>
                            <li>Colors may vary slightly due to monitor settings</li>
                            <li>We are not responsible for manufacturer warranty terms</li>
                        </ul>

                        <h3>4. Pricing and Payments</h3>
                        <ul>
                            <li>All prices are in Rs unless otherwise stated</li>
                            <li>We accept Bank, PayPal, and COD</li>
                            <li>Sales tax will be added where applicable</li>
                            <li>Prices are subject to change without notice</li>
                            <li>Your payment is processed when your order is placed</li>
                        </ul>

                        <h3>5. Shipping and Delivery</h3>
                        <ul>
                            <li>We ship worldwide with various shipping options</li>
                            <li>Delivery times are estimates, not guarantees</li>
                            <li>Shipping costs are calculated at checkout</li>
                            <li>Risk of loss passes to you upon delivery</li>
                            <li>Some products may have shipping restrictions</li>
                        </ul>

                        <h3>6. Returns and Refunds</h3>
                        <p>Our Electronics Return Policy:</p>
                        <ul>
                            <li>30-day return window for most items (exceptions apply)</li>
                            <li>Products must be in original condition with all accessories</li>
                            <li>Return shipping is at customer's expense unless defective</li>
                            <li>Refunds are processed within 7-10 business days</li>
                            <li>Software, downloads, and personalized items are non-refundable</li>
                        </ul>

                        <h3>7. Intellectual Property</h3>
                        <ul>
                            <li>All website content is owned by InnovexMart or its licensors</li>
                            <li>"InnovexMart" and our logo are registered trademarks</li>
                            <li>You may not use our intellectual property without written permission</li>
                            <li>User-generated content becomes our property when posted</li>
                        </ul>

                        <h3>8. Prohibited Activities</h3>
                        <p>You agree not to:</p>
                        <ul>
                            <li>Use our website for any illegal purpose</li>
                            <li>Attempt to gain unauthorized access to our systems</li>
                            <li>Use automated tools to scrape or monitor our site</li>
                            <li>Interfere with the proper functioning of our website</li>
                            <li>Resell our products without authorization</li>
                        </ul>

                        <h3>9. Limitation of Liability</h3>
                        <p>InnovexMart shall not be liable for:</p>
                        <ul>
                            <li>Any indirect, incidental, or consequential damages</li>
                            <li>Product malfunctions covered by manufacturer warranties</li>
                            <li>Errors or omissions in product information</li>
                            <li>Events beyond our reasonable control (force majeure)</li>
                        </ul>

                        <h3>10. Governing Law</h3>
                        <p>These Terms shall be governed by and construed in accordance with the laws of the State of California, without regard to its conflict of law provisions.</p>

                        <h3>11. Changes to Terms</h3>
                        <p>We reserve the right to modify these Terms at any time. Continued use of our website after changes constitutes acceptance of the new Terms.</p>

                        <h3>12. Contact Information</h3>
                        <p>For questions about these Terms, please contact us at:</p>
                        <address>
                            InnovexMart Customer Service<br>
                            211004 Katra<br>
                            Prayagraj uttar Pradesh<br>
                            Email: lorensji@gmail.com<br>
                            Phone: 9795174227
                        </address>

                        <div class="alert alert-warning mt-4">
                            By using our website or purchasing our products, you acknowledge that you have read, understood, and agree to be bound by these Terms and Conditions.
                        </div>
                    </div>
                    
                    <div class="text-center mt-5">
                        <a href="javascript:window.close();" class="btn btn-primary mr-3">I Accept</a>
                        <a href="javascript:window.close();" class="btn btn-outline-secondary">Close</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .terms-content {
        background: #fff;
        padding: 2.5rem;
        border-radius: 10px;
        box-shadow: 0 5px 25px rgba(0,0,0,0.08);
        margin-top: 1rem;
        border: 1px solid #eee;
    }
    
    .terms-content h1 {
        color: #2c3e50;
        font-weight: 700;
        margin-bottom: 1rem;
    }
    
    .terms-content h3 {
        color: #2c3e50;
        margin-top: 2.5rem;
        margin-bottom: 1.2rem;
        font-weight: 600;
        border-bottom: 1px solid #eee;
        padding-bottom: 0.5rem;
    }
    
    .terms-content p, .terms-content ul, .terms-content address {
        color: #555;
        line-height: 1.8;
        font-size: 1.05rem;
    }
    
    .terms-content ul {
        margin-left: 25px;
        margin-bottom: 1.5rem;
    }
    
    .terms-content ul li {
        margin-bottom: 0.7rem;
        position: relative;
        padding-left: 15px;
    }
    
    .terms-content ul li:before {
        content: "•";
        color: #3498db;
        font-weight: bold;
        position: absolute;
        left: 0;
    }
    
    .terms-content address {
        font-style: normal;
        background: #f9f9f9;
        padding: 1rem;
        border-radius: 5px;
        margin-top: 0.5rem;
    }
    
    @media (max-width: 768px) {
        .terms-content {
            padding: 1.5rem;
        }
        
        .terms-content h1 {
            font-size: 1.8rem;
        }
        
        .terms-content h3 {
            font-size: 1.3rem;
        }
    }
</style>

<?php require_once('footer.php'); ?>