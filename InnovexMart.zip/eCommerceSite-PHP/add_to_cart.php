<?php
session_start();

// Assuming you have a PDO connection established
$pdo = new PDO('mysql:host=localhost;dbname=ecommerceweb', 'root', '');

// Check if product ID is set
if (isset($_GET['id'])) {
    $product_id = intval($_GET['id']);

    // Fetch product details from the database
    $statement = $pdo->prepare("SELECT * FROM tbl_product WHERE p_id = ?");
    $statement->execute([$product_id]);
    $product = $statement->fetch(PDO::FETCH_ASSOC);

    if ($product) {
        // Initialize cart if it doesn't exist
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }

        // Add product to cart
        $_SESSION['cart'][$product['p_id']] = [
            'name' => $product['p_name'],
            'price' => $product['p_current_price'],
            'quantity' => 1
        ];

        // Populate session variables for cart items
        if (!isset($_SESSION['cart_p_id'])) {
            $_SESSION['cart_p_id'] = [];
            $_SESSION['cart_p_name'] = [];
            $_SESSION['cart_p_current_price'] = [];
            $_SESSION['cart_p_qty'] = [];
            $_SESSION['cart_p_featured_photo'] = [];
        }
        $_SESSION['cart_p_id'][] = $product['p_id'];
        $_SESSION['cart_p_name'][] = $product['p_name'];
        $_SESSION['cart_p_current_price'][] = $product['p_current_price'];
        $_SESSION['cart_p_qty'][] = 1;
        $_SESSION['cart_p_featured_photo'][] = $product['p_featured_photo'];

        // Add Buy Now and Wishlist buttons
        echo '<a href="checkout.php?id='.$product['p_id'].'" class="btn btn-success">Buy Now</a>';
        echo '<a href="wishlist.php?id='.$product['p_id'].'" class="btn btn-warning"><i class="fa fa-heart"></i> Add to Wishlist</a>';

        // Redirect to the cart page
        header('Location: cart.php');
        exit;
    } else {
        // Redirect to home or show an error
        header('Location: index.php');
        exit;
    }
} else {
    // Redirect to home or show an error
    header('Location: index.php');
    exit;
}
?>
