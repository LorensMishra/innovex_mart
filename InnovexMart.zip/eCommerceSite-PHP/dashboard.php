<?php require_once('header.php'); ?>

<?php
// Check if the customer is logged in or not
if(!isset($_SESSION['customer_logged_in'])) {
    header('location: login.php');
    exit;
}

// Get customer details
$statement = $pdo->prepare("SELECT cust_name, cust_email FROM tbl_customer WHERE cust_id = ?");
$statement->execute([$_SESSION['customer_id']]);
$user = $statement->fetch(PDO::FETCH_ASSOC);
?>

<div class="page">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="user-content">
                    <div class="dashboard-header text-center py-5">
                        <h2 class="mb-3">Welcome, <?php echo htmlspecialchars($user['cust_name']); ?>!</h2>
                        <p class="lead mb-4">Your email: <?php echo htmlspecialchars($user['cust_email']); ?></p>
                        <div class="d-flex justify-content-center gap-3">
                            <a href="profile.php" class="btn btn-primary">View Profile</a>
                            <a href="logout.php" class="btn btn-danger">Logout</a>
                        </div>
                    </div>

                    <div class="dashboard-content mt-5">
                        <div class="row">
                            <div class="col-md-4 mb-4">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">My Orders</h5>
                                        <p class="card-text">View your order history and track your shipments.</p>
                                        <a href="customer-order.php" class="btn btn-primary">View Orders</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">My Profile</h5>
                                        <p class="card-text">Update your personal information and preferences.</p>
                                        <a href="profile.php" class="btn btn-primary">Update Profile</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <div class="card">
                                    <div class="card-body ">
                                        <!-- <i class="fas fa-address-card fa-3x mb-3"></i> -->
                                        <h5 class="card-title">Manage Addresses</h5>
                                        <p class="card-text">Add, edit, or delete your shipping and billing addresses</p>
                                        <a href="customer-billing-shipping-update.php" class="btn btn-primary">Manage Addresses</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .dashboard-header {
        background: #f8f9fa;
        border-radius: 10px;
        padding: 3rem 2rem;
        margin-bottom: 2rem;
    }
    
    .dashboard-header h2 {
        color: #2c3e50;
        font-weight: 600;
    }
    
    .dashboard-header .lead {
        color: #666;
        font-size: 1.1rem;
    }
    
    .dashboard-content .card {
        border: none;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        transition: transform 0.3s ease;
    }
    
    .dashboard-content .card:hover {
        transform: translateY(-5px);
    }
    
    .dashboard-content .card-body {
        padding: 1.5rem;
    }
    
    .dashboard-content .card-title {
        color: #2c3e50;
        font-weight: 500;
        margin-bottom: 1rem;
    }
    
    .dashboard-content .card-text {
        color: #666;
        margin-bottom: 1.5rem;
    }
    
    @media (max-width: 768px) {
        .dashboard-header {
            padding: 2rem 1rem;
        }
        
        .dashboard-content .card {
            margin-bottom: 1rem;
        }
    }
</style>

<?php require_once('footer.php'); ?>