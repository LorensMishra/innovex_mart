<?php
session_start();
require_once('admin/inc/config.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    try {
        // Query to check if user exists
        $stmt = $pdo->prepare("SELECT * FROM students WHERE username = :username OR email = :email");
        $stmt->execute(['username' => $username, 'email' => $username]);
        
        if ($stmt->rowCount() == 1) {
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            // Verify password
            if (password_verify($password, $user['password'])) {
                // Password is correct, create session
                $_SESSION['student_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                
                // Check if remember me is checked
                if (isset($_POST['remember'])) {
                    // Set cookies for 30 days
                    setcookie("student_login", $user['username'], time() + (30 * 24 * 60 * 60), "/");
                }
                
                // Redirect to dashboard
                header("Location: student-dashboard.php");
                exit();
            } else {
                header("Location: student.php?error=Invalid username or password");
                exit();
            }
        } else {
            header("Location: student.php?error=Invalid username or password");
            exit();
        }
    } catch (PDOException $e) {
        header("Location: student.php?error=Database error. Please try again later.");
        exit();
    }
} else {
    header("Location: student.php");
    exit();
}
?>
